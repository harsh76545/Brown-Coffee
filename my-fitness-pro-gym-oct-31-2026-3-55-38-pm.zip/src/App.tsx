import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ProofBar } from './components/ProofBar';
import { ServicesSection } from './components/ServicesSection';
import { ClassSchedule } from './components/ClassSchedule';
import { PricingCalculator } from './components/PricingCalculator';
import { MemberToolsSection } from './components/MemberToolsSection';
import { ReviewsSection } from './components/ReviewsSection';
import { FaqSection } from './components/FaqSection';
import { LocationContactSection } from './components/LocationContactSection';
import { Footer } from './components/Footer';
import { FreeTrialModal } from './components/FreeTrialModal';
import { ServiceModal } from './components/ServiceModal';
import { MarketingStudioModal } from './components/MarketingStudioModal';
import { ServiceItem, PricingPlan, ClassScheduleItem } from './data/gymData';

export default function App() {
  const [isTrialModalOpen, setIsTrialModalOpen] = useState(false);
  const [isMarketingStudioOpen, setIsMarketingStudioOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);
  const [selectedPlanForTrial, setSelectedPlanForTrial] = useState<PricingPlan | null>(null);
  const [selectedClassForTrial, setSelectedClassForTrial] = useState<ClassScheduleItem | null>(null);

  const handleOpenGeneralTrial = () => {
    setSelectedPlanForTrial(null);
    setSelectedClassForTrial(null);
    setIsTrialModalOpen(true);
  };

  const handleSelectPlan = (plan: PricingPlan) => {
    setSelectedPlanForTrial(plan);
    setSelectedClassForTrial(null);
    setIsTrialModalOpen(true);
  };

  const handleReserveClass = (classItem: ClassScheduleItem) => {
    setSelectedClassForTrial(classItem);
    setSelectedPlanForTrial(null);
    setIsTrialModalOpen(true);
  };

  const handleSelectService = (service: ServiceItem) => {
    setSelectedService(service);
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-amber-400 selection:text-neutral-950">
      {/* Top Header */}
      <Navbar
        onOpenTrial={handleOpenGeneralTrial}
        onOpenMarketingStudio={() => setIsMarketingStudioOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        <Hero onOpenTrial={handleOpenGeneralTrial} />
        <ProofBar />
        <ServicesSection onSelectService={handleSelectService} />
        <ClassSchedule onReserve={handleReserveClass} />
        <PricingCalculator onSelectPlan={handleSelectPlan} />
        <MemberToolsSection />
        <ReviewsSection />
        <FaqSection />
        <LocationContactSection />
      </main>

      {/* Quiet Footer */}
      <Footer onOpenMarketingStudio={() => setIsMarketingStudioOpen(true)} />

      {/* Interactive Modals */}
      <FreeTrialModal
        isOpen={isTrialModalOpen}
        onClose={() => setIsTrialModalOpen(false)}
        initialPlan={selectedPlanForTrial}
        initialClass={selectedClassForTrial}
      />

      <ServiceModal
        service={selectedService}
        onClose={() => setSelectedService(null)}
        onBookTrial={handleOpenGeneralTrial}
      />

      <MarketingStudioModal
        isOpen={isMarketingStudioOpen}
        onClose={() => setIsMarketingStudioOpen(false)}
      />
    </div>
  );
}
