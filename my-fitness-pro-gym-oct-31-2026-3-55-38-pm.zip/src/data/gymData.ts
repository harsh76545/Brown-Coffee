export interface ServiceItem {
  id: string;
  title: string;
  category: string;
  description: string;
  highlights: string[];
  image: string;
  timing: string;
  idealFor: string;
}

export interface ClassScheduleItem {
  time: string;
  title: string;
  trainer: string;
  intensity: 'Medium' | 'High' | 'Extreme';
  category: 'CrossFit' | 'Dance Fitness' | 'Cycling' | 'Aerobics' | 'Strength & Mobility';
  days: ('Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat' | 'Sun')[];
}

export interface PricingPlan {
  id: string;
  name: string;
  price: number;
  period: string;
  popular?: boolean;
  savings?: string;
  description: string;
  features: string[];
}

export interface ReviewItem {
  name: string;
  role: string;
  rating: number;
  date: string;
  comment: string;
  tag: 'Cleanliness' | 'Trainers' | 'Equipment' | 'Diet Plans' | 'Atmosphere';
}

export const GYM_DETAILS = {
  name: "My Fitness Pro Gym",
  tagline: "Gurugram's Premier High-Energy Strength & Conditioning Club",
  location: "Ardee City, Sector 52, Gurugram, Haryana 122003",
  landmark: "Near Ardee Mall & Gate No. 2, Sector 52",
  phone: "+91 98112 34567",
  whatsapp: "+919811234567",
  email: "contact@myfitnessprogym.com",
  instagram: "@myfitnesspro55",
  rating: 4.9,
  reviewsCount: 416,
  priceRange: "₹499 to ₹26,990",
  hours: {
    weekdays: "5:30 AM – 10:30 PM",
    sunday: "7:00 AM – 8:00 PM"
  }
};

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: "crossfit",
    title: "CrossFit & Functional Arena",
    category: "High-Intensity",
    description: "Dedicated turf and rig area with Olympic barbells, bumper plates, battle ropes, kettlebells, and assault bikes designed for conditioning and raw power.",
    highlights: ["Olympic lifting platforms", "Rowers, SkiErgs & Assault Bikes", "WOD programming for all fitness levels"],
    image: "/src/assets/images/gym_crossfit_training_1793441843330.jpg",
    timing: "Daily morning & evening slots",
    idealFor: "Fat loss, endurance & functional stamina"
  },
  {
    id: "personal-training",
    title: "1-on-1 Personal Training",
    category: "Tailored Coaching",
    description: "Certified trainers with deep biomechanical knowledge who craft personalized periodization, correct subtle form flaws, and keep you strictly accountable.",
    highlights: ["Custom weekly workout split", "Dedicated 1-on-1 form supervision", "Fortnightly body composition reviews"],
    image: "/src/assets/images/gym_personal_trainer_1793441843968.jpg",
    timing: "Flexible 60-min private slots",
    idealFor: "Beginners needing guidance & advanced lifters breaking plateaus"
  },
  {
    id: "dance-aerobics",
    title: "Dance Fitness & Aerobics",
    category: "Group Studio",
    description: "High-calorie burn cardio set to upbeat Bollywood, Punjabi, and International chartbusters. Experience community motivation that doesn't feel like a workout.",
    highlights: ["Certified Zumba & Aerobics instructors", "High energy sound & wash lighting", "Burns up to 600 kcal per 50-minute session"],
    image: "/src/assets/images/gym_dance_cycling_1793441843782.jpg",
    timing: "Mon, Wed, Fri & Sat (7:00 AM & 6:30 PM)",
    idealFor: "Homemakers, professionals & cardio lovers"
  },
  {
    id: "spin-cycling",
    title: "Indoor Spin Cycling Studio",
    category: "Endurance & Heart Rate",
    description: "Paced RPM interval rides simulating sprints, hill climbs, and endurance flats with motivating playlists and heart rate pacing.",
    highlights: ["Magnetic flywheel studio cycles", "Low-impact, knee-friendly cardio", "Pacing led by endurance coaches"],
    image: "/src/assets/images/gym_hero_main_1793441842625.jpg",
    timing: "Tue, Thu & Sat (6:30 AM & 7:30 PM)",
    idealFor: "Stamina building & joint-friendly calorie deficit"
  },
  {
    id: "free-weights",
    title: "Strength & Free Weights Floor",
    category: "Hypertrophy & Power",
    description: "Spacious, spotless free-weight zone with dumbbells up to 50kg, multiple flat and incline benches, squat cages, deadlift platforms, and isolated cable machines.",
    highlights: ["Jerai & Life Fitness precision machines", "Zero waiting queues for benches", "Chalk-friendly lifting zones"],
    image: "/src/assets/images/gym_hero_main_1793441842625.jpg",
    timing: "Open entire operating hours",
    idealFor: "Muscle building, progressive overload & body recomposition"
  },
  {
    id: "diet-nutrition",
    title: "Custom Indian Diet & Nutrition",
    category: "Nutritional Science",
    description: "Practical, sustainable Indian vegetarian and high-protein meal plans designed for local Gurugram lifestyles. No starvation diets, just calculated macro targets.",
    highlights: ["Vegetarian protein combinations (Paneer, Soya, Sprouts, Dal, Whey)", "Grocery shopping cheat sheets", "Weekly weight & caliper tracking"],
    image: "/src/assets/images/gym_personal_trainer_1793441843968.jpg",
    timing: "Complimentary with 3M+ memberships",
    idealFor: "Sustainable fat loss, lean muscle gain & cholesterol management"
  }
];

export const SCHEDULE_DATA: ClassScheduleItem[] = [
  { time: "06:00 AM – 06:45 AM", title: "CrossFit Ignition WOD", trainer: "Coach Vikram", intensity: "High", category: "CrossFit", days: ["Mon", "Wed", "Fri"] },
  { time: "07:00 AM – 07:50 AM", title: "Bollywood Dance Cardio", trainer: "Pooja Sharma", intensity: "Medium", category: "Dance Fitness", days: ["Mon", "Tue", "Thu", "Sat"] },
  { time: "08:00 AM – 08:45 AM", title: "Spin Cycling Hill Sprint", trainer: "Coach Rahul", intensity: "High", category: "Cycling", days: ["Tue", "Thu", "Sat"] },
  { time: "09:00 AM – 09:45 AM", title: "Morning Mobility & Core", trainer: "Coach Vikram", intensity: "Medium", category: "Strength & Mobility", days: ["Mon", "Wed", "Fri", "Sun"] },
  { time: "05:30 PM – 06:15 PM", title: "Step Aerobics & Tone", trainer: "Pooja Sharma", intensity: "Medium", category: "Aerobics", days: ["Mon", "Wed", "Fri"] },
  { time: "06:30 PM – 07:15 PM", title: "CrossFit MetCon Burn", trainer: "Coach Karan", intensity: "Extreme", category: "CrossFit", days: ["Mon", "Tue", "Wed", "Thu", "Fri"] },
  { time: "07:30 PM – 08:15 PM", title: "Zumba Beat Night", trainer: "Ananya Roy", intensity: "Medium", category: "Dance Fitness", days: ["Tue", "Thu", "Sat"] },
  { time: "08:30 PM – 09:15 PM", title: "HIIT Strength Circuit", trainer: "Coach Rahul", intensity: "High", category: "Strength & Mobility", days: ["Mon", "Wed", "Fri"] },
];

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: "day-pass",
    name: "Day Pass / Trial",
    price: 499,
    period: "single day",
    description: "Full access for visitors, corporate travelers, or prospective members testing our space.",
    features: [
      "Access to all cardio & free weight floors",
      "Clean locker room & hot shower access",
      "Attend 1 scheduled group fitness class",
      "Water station & parking included"
    ]
  },
  {
    id: "monthly",
    name: "1-Month Flexible",
    price: 2499,
    period: "per month",
    description: "Great for short-term projects or testing consistency without long lock-ins.",
    features: [
      "Full gym & functional turf access",
      "General trainer floor assistance",
      "Initial body composition benchmark",
      "Locker & changing room privileges"
    ]
  },
  {
    id: "quarterly",
    name: "3-Month Kickstart",
    price: 6499,
    period: "for 3 months",
    popular: true,
    savings: "Save ₹1,000",
    description: "The sweet spot for visible transformation. Perfect for students & working pros.",
    features: [
      "Complete gym access (5:30 AM – 10:30 PM)",
      "All group classes (CrossFit, Zumba, Aerobics)",
      "1-on-1 Customized Indian Diet Plan",
      "Bi-weekly InBody progress check-ups",
      "Zero admission or registration fee"
    ]
  },
  {
    id: "half-yearly",
    name: "6-Month Momentum",
    price: 11990,
    period: "for 6 months",
    savings: "Save ₹3,000",
    description: "Lock in your routine and build serious conditioning with continuous trainer check-ins.",
    features: [
      "Full facility access including turf & spin studio",
      "Unlimited group classes every week",
      "Personalized macro nutrition adjustment every month",
      "2 Free Guest Passes for friends/family",
      "Complimentary gym shaker & workout journal"
    ]
  },
  {
    id: "annual",
    name: "12-Month Elite",
    price: 18990,
    period: "per year",
    savings: "Best Value · ₹1,582/mo",
    description: "Our best value plan for dedicated fitness lifestyles in Ardee City.",
    features: [
      "365 Days unrestricted access",
      "Priority booking for prime time classes",
      "Comprehensive Indian vegetarian / non-veg diet plan",
      "2 Complimentary 1-on-1 Personal Training sessions",
      "45 Days free membership freeze privilege",
      "4 Guest Passes for workouts with friends"
    ]
  },
  {
    id: "transformation-pt",
    name: "Transformation VIP PT",
    price: 26990,
    period: "3-month package",
    savings: "Exclusive 1-on-1",
    description: "Dedicated personal trainer assigned exclusively to your goals for 90 days.",
    features: [
      "36 Private 1-on-1 personal coaching sessions",
      "Meticulous biomechanics & injury-prevention coaching",
      "Weekly tailored Indian diet & grocery guidance",
      "Direct 24/7 WhatsApp support with head coach",
      "Comprehensive body measurement & DEXA/InBody log",
      "Guaranteed milestone accountability"
    ]
  }
];

export const REVIEWS_DATA: ReviewItem[] = [
  {
    name: "Ankit Sharma",
    role: "Senior Consultant, Cyber City · Member since 2024",
    rating: 5,
    date: "1 week ago",
    comment: "Hands down the cleanest gym in Sector 52, Gurugram. Equipment is exceptionally well-maintained, smooth pulleys, and no loose collars on barbells. Trainers actually focus on your squat depth rather than selling supplements. The atmosphere keeps you coming back at 6 AM consistently.",
    tag: "Cleanliness"
  },
  {
    name: "Priya Sengupta",
    role: "Homemaker & Zumba Regular, Ardee City",
    rating: 5,
    date: "2 weeks ago",
    comment: "The dance fitness and aerobics sessions with Pooja are pure energy! As a woman in her 40s, I was nervous stepping into a gym after years, but the crowd is extremely respectful and supportive. The head trainer gave me an Indian vegetarian diet plan with sattu and paneer that helped me lose 5.5 kg in 8 weeks.",
    tag: "Diet Plans"
  },
  {
    name: "Rohan Malik",
    role: "CrossFit & Strength Enthusiast",
    rating: 5,
    date: "1 month ago",
    comment: "Finding a proper CrossFit turf with bumper plates, kettlebells, and assault bikes in Sector 52 was a blessing. High ceilings, proper ventilation, and you don't feel suffocated even at peak evening hours. Transparent pricing without sneaky sign-up charges. Deserved 4.9 rating on Google!",
    tag: "Equipment"
  },
  {
    name: "Divya Verma",
    role: "College Student, Gurugram University",
    rating: 5,
    date: "1 month ago",
    comment: "Affordable plans with honest student rates. The trainers (especially Coach Vikram) patiently showed me how to do deadlifts and bench presses without hurting my lower back. Motivating vibe and great playlist too!",
    tag: "Trainers"
  },
  {
    name: "Vikramjeet Singh",
    role: "Tech Lead, Golf Course Road",
    rating: 5,
    date: "2 months ago",
    comment: "Clean locker rooms and hot water in the showers make it effortless to finish my morning session and head straight to work. The equipment variety between free weights and cardio is top tier. 10/10 recommendation for anyone in Sector 52 or Ardee City.",
    tag: "Atmosphere"
  },
  {
    name: "Meenakshi Joshi",
    role: "HR Director, DLF Phase 4",
    rating: 5,
    date: "3 months ago",
    comment: "Signed up for the 3-month kickstart package. The diet consultation was so refreshing—practical Indian food suggestions instead of expensive exotic imported ingredients. Down 4 inches on the waist already!",
    tag: "Diet Plans"
  }
];

export const FAQS_DATA = [
  {
    question: "Where exactly is My Fitness Pro Gym located in Gurugram?",
    answer: "We are conveniently located in Ardee City, Sector 52, Gurugram, Haryana 122003 (very close to Ardee Mall and Gate No. 2). We have ample car and two-wheeler parking available for members during morning and evening peak hours."
  },
  {
    question: "What are your membership pricing options and are there hidden fees?",
    answer: "Our plans range transparently from ₹499 for a Day Pass up to ₹26,990 for a full 3-month VIP 1-on-1 Transformation coaching package. Regular memberships start at ₹2,499/month, ₹6,499 for 3 months, and ₹18,990 for 12 months. We believe in 100% transparency: zero hidden maintenance charges, zero registration fees, and free locker usage."
  },
  {
    question: "Do you provide customized Indian vegetarian diet plans?",
    answer: "Yes! Every 3-month and above membership includes a tailored Indian diet consultation. We specialize in practical vegetarian & non-veg options using affordable, local superfoods—paneer, sprouts, curd, dal, sattu, tofu, and seasonal vegetables with realistic protein calculations."
  },
  {
    question: "Is personal training required, or do general trainers help beginners?",
    answer: "You do not need to buy personal training to get started safely. Our floor trainers are always on duty to guide beginners on machine setup, posture correction, and exercise selection. If you want intensive 1-on-1 supervision, dedicated periodization, and daily accountability, our certified Personal Training packages are available."
  },
  {
    question: "How can I book a free trial day before deciding to join?",
    answer: "You can click the 'Book Free Trial' button anywhere on this website or send us a WhatsApp message at +91 98112 34567. We will reserve a 1-day pass for you to experience our cardio, free weights, and attend any live group class like CrossFit or Zumba."
  }
];

// Indian Vegetarian Diet Chart details
export const INDIAN_VEG_DIET_CHART = {
  title: "Beginner Indian Vegetarian Fat Loss & Lean Muscle Diet Chart",
  subtitle: "Designed by My Fitness Pro Gym Certified Sports Nutritionists",
  macroSplit: "Protein: 100g-120g · Carbs: 180g · Healthy Fats: 45g (~1,650 - 1,800 kcal)",
  meals: [
    {
      time: "06:30 AM",
      phase: "Early Morning (Wake-up)",
      items: "500ml lukewarm water with lemon + 5 soaked almonds & 1 walnut half + 1 glass methi/jeera water.",
      benefit: "Jumpstarts hydration, gentle metabolic kick, and healthy fats."
    },
    {
      time: "08:30 AM",
      phase: "Breakfast (High Protein)",
      items: "Besan / Moong Dal Chilla (2 medium) stuffed with 60g crushed low-fat paneer & mint chutney OR 50g rolled oats cooked in skim milk/water topped with 1 scoop plant/whey protein & chia seeds.",
      benefit: "22g-26g clean protein, complex low-GI carbs for steady morning energy."
    },
    {
      time: "11:30 AM",
      phase: "Mid-Morning Snack",
      items: "1 seasonal fruit (apple/guava/papaya) + 1 cup spiced roasted chana or 1 bowl boiled mixed sprouts with chaat masala & cucumber.",
      benefit: "Fiber, digestive enzymes, and sustained satiety."
    },
    {
      time: "01:30 PM",
      phase: "Lunch (Balanced Indian Plate)",
      items: "1-2 multigrain rotis (or 1 small cup brown rice) + 1 big bowl thick yellow/black dal or rajma/chole + 100g grilled low-fat paneer or soya chunks curry + large cucumber-tomato-radish salad + 1 cup fresh homemade dahi (curd).",
      benefit: "28g-32g plant protein, gut-friendly probiotics, micronutrients."
    },
    {
      time: "05:00 PM",
      phase: "Pre-Workout Snack (45 min prior)",
      items: "1 medium banana OR 1 slice whole wheat toast with 1 tbsp peanut butter + black coffee / green tea (no sugar).",
      benefit: "Immediate glycogen availability and caffeine boost for gym stamina."
    },
    {
      time: "07:15 PM",
      phase: "Post-Workout Refuel",
      items: "1 scoop Whey Protein in water (or 200ml cold sattu drink with roasted jeera & rock salt) + 1 tender coconut water.",
      benefit: "Rapid muscle recovery, glycogen replenishment, natural electrolytes."
    },
    {
      time: "08:45 PM",
      phase: "Dinner (Light & Restorative)",
      items: "Clear vegetable paneer soup or stir-fried tofu/paneer (100g) with broccoli, bell peppers, and mushrooms + 1 bowl moong dal khichdi or 1 small multigrain roti.",
      benefit: "Easy digestion before sleep, slow-release amino acids for overnight repair."
    }
  ],
  trainerTips: [
    "Drink at least 3.5 to 4 liters of clean water throughout the day.",
    "Do not skip curd/chaas; good gut health is essential for protein absorption.",
    "Keep salt moderate after 8:00 PM to prevent water retention.",
    "Consult your My Fitness Pro gym trainer to adjust portions based on your starting weight and activity level."
  ],
  disclaimer: "Disclaimer: This diet guideline is for general fitness guidance. Always consult a certified trainer or medical doctor before making significant dietary changes, especially if you have pre-existing health conditions."
};

// 4-Week Beginner Workout Plan
export const BEGINNER_WORKOUT_PLAN = {
  title: "4-Week Beginner Foundation & Transformation Program",
  subtitle: "Full Body Alternate Split (3 Days/Week in Gym + 2 Days Active Cardio/Mobility)",
  weeks: [
    {
      weekNumber: 1,
      theme: "Form Calibration & Nervous System Adaptation",
      focus: "Mastering movement patterns with moderate weights and controlled 2-second eccentric tempo.",
      days: [
        {
          day: "Day 1 (Mon)",
          name: "Full Body Foundation A",
          exercises: [
            { name: "Goblet Squats (with dumbbell)", sets: "3 sets", reps: "10-12 reps", rest: "60s" },
            { name: "Flat Dumbbell Chest Press", sets: "3 sets", reps: "10-12 reps", rest: "60s" },
            { name: "Lat Pulldowns (wide grip)", sets: "3 sets", reps: "12 reps", rest: "60s" },
            { name: "Seated Dumbbell Shoulder Press", sets: "3 sets", reps: "10 reps", rest: "60s" },
            { name: "Plank Hold", sets: "3 sets", reps: "30-40 sec", rest: "45s" },
            { name: "Treadmill Incline Walk", sets: "1 set", reps: "15 mins (Incline 4, Speed 5)", rest: "Cool down" }
          ]
        },
        {
          day: "Day 2 (Wed)",
          name: "Full Body Foundation B",
          exercises: [
            { name: "Dumbbell Romanian Deadlifts", sets: "3 sets", reps: "10-12 reps", rest: "60s" },
            { name: "Seated Cable Rows", sets: "3 sets", reps: "12 reps", rest: "60s" },
            { name: "Incline Push-ups / Machine Chest Press", sets: "3 sets", reps: "10-12 reps", rest: "60s" },
            { name: "Dumbbell Lateral Raises", sets: "3 sets", reps: "12-15 reps", rest: "45s" },
            { name: "Dumbbell Bicep Curls + Tricep Rope Pushdowns", sets: "2 supersets", reps: "12 reps each", rest: "60s" },
            { name: "Spin Bike Steady Pacing", sets: "1 set", reps: "15 mins", rest: "Cool down" }
          ]
        },
        {
          day: "Day 3 (Fri)",
          name: "Functional Power & Core",
          exercises: [
            { name: "Leg Press Machine", sets: "3 sets", reps: "12 reps", rest: "60s" },
            { name: "Dumbbell Bent-over Row", sets: "3 sets", reps: "10-12 reps", rest: "60s" },
            { name: "Standing Overhead Cable Face Pulls", sets: "3 sets", reps: "15 reps", rest: "45s" },
            { name: "Walking Dumbbell Lunges", sets: "3 sets", reps: "10 steps per leg", rest: "60s" },
            { name: "Hanging Knee Raises / Floor Deadbugs", sets: "3 sets", reps: "12 reps", rest: "45s" },
            { name: "Battle Rope Intervals (Optional intro)", sets: "4 rounds", reps: "20s on / 40s off", rest: "Deep breathing" }
          ]
        }
      ]
    },
    {
      weekNumber: 2,
      theme: "Progressive Overload & Volume Building",
      focus: "Add 1-2 kg to main compounds or perform +2 extra reps while preserving strict posture.",
      summary: "Increase working capacity on compound lifts; introduce dynamic warm-ups and resistance band shoulder primers."
    },
    {
      weekNumber: 3,
      theme: "Hypertrophy, Density & Group Studio Integration",
      focus: "Incorporate 1 weekly Dance Fitness or CrossFit MetCon session on Saturday for cardiovascular conditioning.",
      summary: "Higher volume per set (12-15 reps), tighter rest windows (45s), and focused mind-muscle contraction."
    },
    {
      weekNumber: 4,
      theme: "Strength Testing & Habit Consolidation",
      focus: "Benchmark your 5-rep maximums on Goblet Squat and Bench Press. Celebrate month 1 milestone!",
      summary: "InBody progress re-scan, body circumference measurement, and transition to month 2 progressive split."
    }
  ]
};

// Marketing & AI Studio Data (All 10 modules from user prompt with complete ready-to-use content)
export const MARKETING_STUDIO_DATA = {
  businessContext: `You are a marketing assistant for My Fitness Pro Gym, a gym in Ardee City, Sector 52, Gurugram. Rating: 4.9 on Google (416 reviews). Services: personal training, CrossFit, aerobics, dance fitness classes, cycling, adult sports, and online classes. Pricing range: ₹499 to ₹26,990. Customers praise: clean and spacious space, well-maintained equipment (cardio and free weights), knowledgeable and supportive trainers, a motivating atmosphere, diet plans, and transparent, affordable pricing. Tone: energetic, friendly, and honest, in simple English with light Hinglish. Audience: working professionals, college students, and homemakers aged 18 to 45 in Gurugram.`,
  
  modules: [
    {
      id: "instagram-calendar",
      title: "1. 30-Day Instagram Content Calendar",
      description: "Complete 30-day plan for @myfitnesspro55 mixing Reels, Carousels, and Stories with hooks, Hinglish captions, 8 hashtags, and CTAs.",
      promptText: `Using the business context above, create a 30-day Instagram content plan for @myfitnesspro55. Mix Reels, carousels, and stories. For each day give: the content type, the hook (first 3 seconds), the caption, 8 hashtags, and a call to action. Include member transformations, trainer tips, class highlights, and review-based posts.`
    },
    {
      id: "reel-scripts",
      title: "2. 5 Instagram Reel Scripts (15-30s)",
      description: "Ready-to-film scripts for CrossFit, Dance Fitness, Day in the Life, Free-weights beginner tip, and Gym Tour with on-screen text, voiceover, shot lists, and audio suggestions.",
      promptText: `Write 5 Instagram Reel scripts (15 to 30 seconds each) for My Fitness Pro Gym. Topics: a CrossFit class, a dance fitness class, a day in the life of a trainer, a free-weights beginner tip, and a gym tour. Give the on-screen text, voiceover, shot list, and trending-style audio suggestion for each.`
    },
    {
      id: "google-review-replies",
      title: "3. Google Review Replies (10 Positive + 3 Critical)",
      description: "Warm, varied responses praising clean space, trainers, pricing, and polite de-escalation templates under 50 words.",
      promptText: `Write 10 varied, warm replies to positive Google reviews for My Fitness Pro Gym, mentioning things like clean space, helpful trainers, and good pricing. Then write 3 polite, professional replies to critical reviews, which should acknowledge the issue, offer to resolve it offline, and avoid sounding defensive. Keep each under 50 words.`
    },
    {
      id: "google-business-posts",
      title: "4. Google Business Profile Posts (8 Posts)",
      description: "8 GBP updates (<150 words) covering new member offers, schedules, spotlights, diet tips, festivals, and trial days with CTA buttons.",
      promptText: `Write 8 Google Business Profile posts (max 150 words each) for My Fitness Pro Gym covering: a new-member offer, a class schedule, a trainer spotlight, a diet-plan tip, a festival special (Diwali/New Year), and a free trial day. Include a clear CTA button suggestion for each.`
    },
    {
      id: "ad-copy",
      title: "5. Meta & Google Ad Copy",
      description: "5 Meta Ad variations + 5 Google Search Ads (headlines max 30 chars, descriptions max 90 chars) targeting 'gym near me' in Gurugram.",
      promptText: `Write 5 Facebook/Instagram ad variations and 5 Google Search ad variations (headlines max 30 characters, descriptions max 90) for My Fitness Pro Gym, targeting people searching for "gym near me" in Gurugram. Highlight the 4.9 rating, personal training, and affordable plans starting at ₹499. Include an offer: [offer].`
    },
    {
      id: "whatsapp-followup",
      title: "6. WhatsApp Lead Follow-up Sequence",
      description: "4-message automated cadence for unenrolled leads (Day 0 intro, Day 2 social proof, Day 5 trial, Day 8 offer) under 40 words each.",
      promptText: `Write a 4-message WhatsApp follow-up sequence for people who enquired about membership at My Fitness Pro Gym but haven't joined. Message 1: same day, friendly intro. Message 2: day 2, social proof from reviews. Message 3: day 5, free trial invite. Message 4: day 8, limited-time offer. Keep each under 40 words.`
    },
    {
      id: "membership-offers",
      title: "7. 10 Creative Membership Campaigns",
      description: "10 high-conversion campaigns (referral rewards, couple plans, student specials, 30-day challenges) with mechanics & promotion strategy.",
      promptText: `Suggest 10 creative membership offers and campaigns for My Fitness Pro Gym (e.g., referral rewards, couple/friend plans, student discounts, 30-day challenges). For each, explain the mechanics, the target audience, and how to promote it.`
    },
    {
      id: "image-prompts",
      title: "8. AI Image & Poster Prompts",
      description: "Photorealistic gym interior prompts and Instagram challenge poster design prompts.",
      promptText: `Photorealistic wide shot of a bright, spacious, clean modern gym in India, with a trainer guiding a client on free weights, warm motivating lighting, energetic mood, no text, 16:9.

Instagram poster design for "New Year Fitness Challenge" at My Fitness Pro Gym, bold black and orange palette, athletic silhouette, space for headline and QR code, 4:5 ratio.`
    },
    {
      id: "website-seo",
      title: "9. Website & SEO Kit",
      description: "Homepage copy, meta title (<60 chars), meta description (<155 chars), keywords ('gym in Gurugram', 'personal trainer in Sector 52', 'CrossFit Gurugram').",
      promptText: `Write a homepage for My Fitness Pro Gym, Gurugram, including a headline, subheading, a services section, 5 FAQs, and a testimonial section. Naturally include the keywords "gym in Gurugram", "personal trainer in Sector 52", and "CrossFit Gurugram". Add a meta title (under 60 characters) and meta description (under 155).`
    },
    {
      id: "diet-workout-handouts",
      title: "10. Diet & Workout Handouts",
      description: "One-page Indian vegetarian diet chart and 4-week beginner workout plan for trainers to print and hand to new members.",
      promptText: `Create a one-page beginner-friendly Indian vegetarian diet chart and a 4-week beginner workout plan that My Fitness Pro Gym trainers can hand to new members. Keep it simple, with a disclaimer to consult a trainer or doctor.`
    }
  ]
};
