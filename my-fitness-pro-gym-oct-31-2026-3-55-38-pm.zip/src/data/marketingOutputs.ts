export interface InstagramPost {
  day: number;
  type: 'Reel' | 'Carousel' | 'Story';
  hook: string;
  caption: string;
  hashtags: string[];
  cta: string;
  category: 'Transformation' | 'Trainer Tip' | 'Class Highlight' | 'Review Proof' | 'Vibe';
}

export interface ReelScript {
  id: string;
  topic: string;
  duration: string;
  audioSuggestion: string;
  onScreenText: string[];
  voiceover: string;
  shotList: { shot: string; visual: string }[];
}

export interface ReviewReply {
  id: number;
  type: 'positive' | 'critical';
  reviewSnippet: string;
  replyText: string;
  mentionKeyword: string;
}

export interface GbpPost {
  id: number;
  title: string;
  content: string;
  ctaButton: 'Book' | 'Call Now' | 'Learn More' | 'Get Offer';
}

export interface AdCopyItem {
  platform: 'Meta' | 'Google';
  headline: string;
  description: string;
  targetAudience: string;
}

export interface WhatsAppMessage {
  step: string;
  timing: string;
  text: string;
  goal: string;
}

export interface MembershipOffer {
  id: number;
  title: string;
  badge: string;
  mechanics: string;
  targetAudience: string;
  promotionPlaybook: string;
}

// 1. Instagram 30-Day Calendar Data
export const INSTAGRAM_30_DAYS: InstagramPost[] = [
  {
    day: 1,
    type: "Reel",
    hook: "Gurugram mein aisi gym dekhi hai jahan waiting zero hai? 🏋️‍♂️",
    caption: "Say goodbye to waiting 15 minutes just to get a bench press! Welcome to My Fitness Pro Gym, Ardee City Sector 52. Clean vibes, heavy weights, and real community support. Aaj hi trial book karo!",
    hashtags: ["#GurugramFitness", "#Sector52Gym", "#ArdeeCity", "#GymInGurugram", "#FitIndia", "#GymReels", "#GurgaonGym", "#MyFitnessPro"],
    cta: "DM 'TRIAL' to claim your free 1-day pass today!",
    category: "Vibe"
  },
  {
    day: 2,
    type: "Carousel",
    hook: "5 Indian Vegetarian Protein sources that actually hit 100g protein daily 🥗",
    caption: "Who says vegetarians can't build solid muscle in Gurugram? Swipe to see our head nutritionist's approved daily grocery list featuring paneer, roasted chana, sattu, and soya chunks without expensive imported powders. Save this post for your next grocery run!",
    hashtags: ["#VegetarianFitness", "#DesiDiet", "#HighProteinVeg", "#GurgaonFit", "#Sector52", "#IndianDietPlan", "#GymNutrition", "#FitnessPro"],
    cta: "Save this post and drop your favorite source in the comments below!",
    category: "Trainer Tip"
  },
  {
    day: 3,
    type: "Story",
    hook: "Morning 7:00 AM Zumba batch is already on fire 🔥",
    caption: "Pure energy with Coach Pooja! Bollywood beats + 500 kcal burned before you even open your office laptop.",
    hashtags: ["#ZumbaGurugram", "#DanceFitness", "#ArdeeCity", "#MorningWorkout", "#GurgaonWomen", "#GymLife", "#FitnessGoals", "#Sector52"],
    cta: "Swipe up / Tap link in bio to join tomorrow's session!",
    category: "Class Highlight"
  },
  {
    day: 4,
    type: "Reel",
    hook: "Stop doing deadlifts like this if you care about your lower back! ❌",
    caption: "Coach Vikram breaks down the #1 mistake 90% of beginners make in Gurugram gyms. Keep the bar hugging your shins and engage the lats! Tag a gym bro who needs to see this.",
    hashtags: ["#DeadliftForm", "#GymTips", "#FitnessIndia", "#Sector52Gurugram", "#PersonalTrainer", "#GymMistakes", "#StrengthTraining", "#MyFitnessPro"],
    cta: "Save for your next leg day & tag your workout partner!",
    category: "Trainer Tip"
  },
  {
    day: 5,
    type: "Carousel",
    hook: "416 Google Reviews & 4.9 Stars! Here is what Gurugram has to say ⭐",
    caption: "From spotless locker rooms to trainers who actually guide you without pushing PT—read why working pros and college students across Sector 52 call us their second home.",
    hashtags: ["#GoogleReviews", "#4Point9Stars", "#GurgaonFitness", "#ArdeeCityGym", "#CleanGym", "#VerifiedReviews", "#FitGurgaon", "#BestGymGurugram"],
    cta: "Read full reviews on Google or tap link in bio to experience it yourself!",
    category: "Review Proof"
  },
  {
    day: 6,
    type: "Reel",
    hook: "Corporate desk job killing your spine? Try this 30-second mobility drill 🧘‍♂️",
    caption: "Sitting 9 hours in Cyber City or Golf Course Road? Do this thoracic spine opener between your sets. Hamare trainers form par hamesha dhyan dete hain. Comment 'WORKOUT' for our full desk-to-gym guide!",
    hashtags: ["#CorporateFitness", "#CyberCityGurgaon", "#PostOfficeWorkout", "#MobilityDrill", "#Sector52", "#WorkLifeBalance", "#FitnessIndia", "#MyFitnessPro"],
    cta: "Comment 'WORKOUT' and we will DM you the PDF guide!",
    category: "Trainer Tip"
  },
  {
    day: 7,
    type: "Story",
    hook: "Sunday Community Cycling Challenge Highlights 🚴‍♂️",
    caption: "45 minutes of hill sprints and high RPM endurance with our cycling crew. Next batch opens next Sunday!",
    hashtags: ["#SpinCycling", "#IndoorCycling", "#SundayFitness", "#GurgaonCyclists", "#Sector52", "#ArdeeCity", "#CardioBurn", "#FitnessPro"],
    cta: "Vote in poll: Are you a morning cardio person or evening lifter?",
    category: "Class Highlight"
  },
  {
    day: 8,
    type: "Reel",
    hook: "Meet Rohit: From 86kg to 72kg in 90 Days right here in Sector 52 🏆",
    caption: "No crazy starvations. Just consistent 4 days a week at My Fitness Pro Gym and an honest Indian diet plan. Rohit proved that desk job + fitness is 100% possible. Proud of you bhai!",
    hashtags: ["#TransformationTuesday", "#WeightLossJourney", "#FitIndia", "#GurgaonFitness", "#RealTransformation", "#PersonalTraining", "#Sector52", "#MyFitnessPro"],
    cta: "Send us a message to start your 90-day transformation blueprint!",
    category: "Transformation"
  },
  {
    day: 9,
    type: "Carousel",
    hook: "Gym fees from ₹499 to ₹26,990: What do you actually get? 💳",
    caption: "Zero hidden charges. Transparent pricing for college students, working professionals, and homemakers. Swipe to see what's included in every plan from day pass to 1-on-1 VIP coaching.",
    hashtags: ["#TransparentPricing", "#GurugramGym", "#AffordableFitness", "#StudentDiscount", "#Sector52", "#ArdeeCity", "#FitGurgaon", "#NoHiddenFees"],
    cta: "Which plan fits your schedule? Drop a comment or DM us!",
    category: "Vibe"
  },
  {
    day: 10,
    type: "Story",
    hook: "Cleanliness check done! Spotless floors & sanitized dumbbells ✨",
    caption: "We deep clean every cardio machine, free weight rack, and shower area 3 times daily. Because hygiene is non-negotiable.",
    hashtags: ["#CleanGym", "#HygieneFirst", "#Sector52Gurugram", "#ArdeeCity", "#SafeGym", "#FitIndia", "#GurgaonLife", "#MyFitnessPro"],
    cta: "Come visit today between 5:30 AM and 10:30 PM!",
    category: "Vibe"
  },
  {
    day: 11,
    type: "Reel",
    hook: "CrossFit turf battle ropes: Are you doing them the right way? ⚡",
    caption: "Stop flailing your arms! Drive power from your hips and brace your core. Watch Coach Karan show the power wave technique.",
    hashtags: ["#CrossFitGurugram", "#BattleRopes", "#FunctionalFitness", "#Sector52", "#ArdeeCity", "#HIITWorkout", "#StrengthAndConditioning", "#FitnessIndia"],
    cta: "Double tap if you felt the burn just watching this!",
    category: "Trainer Tip"
  },
  {
    day: 12,
    type: "Carousel",
    hook: "The Ultimate Pre-Workout vs Post-Workout Desi Meal Guide 🍌",
    caption: "Banana + peanut butter vs Sattu + coconut water. How to fuel your lifts and accelerate muscle recovery without breaking the bank in Gurugram.",
    hashtags: ["#DesiNutrition", "#PreWorkoutMeal", "#PostWorkout", "#SattuPower", "#IndianBodybuilding", "#Sector52", "#ArdeeCity", "#NutritionTips"],
    cta: "Bookmark this post so you never wonder what to eat before gym!",
    category: "Trainer Tip"
  },
  {
    day: 13,
    type: "Story",
    hook: "Locker room tour: Hot showers, private lockers, spotless mirrors 🚿",
    caption: "Finish your workout, take a fresh shower, and head directly to work in DLF or Cyber City. Zero hassle.",
    hashtags: ["#LockerTour", "#GymAmenities", "#Sector52", "#GurgaonWorkingPros", "#Convenience", "#GymLife", "#ArdeeCity", "#MyFitnessPro"],
    cta: "DM us for a quick virtual tour or walk in anytime!",
    category: "Vibe"
  },
  {
    day: 14,
    type: "Reel",
    hook: "POV: You finally found a gym where trainers don't ignore you 👀",
    caption: "At My Fitness Pro, whether you buy PT or general membership, our trainers are always on the floor helping you correct form and load weights. Yehi hamara promise hai!",
    hashtags: ["#SupportiveTrainers", "#NoEgoLifting", "#GurgaonGyms", "#Sector52", "#BeginnerFriendly", "#FitnessCommunity", "#Gurugram", "#MyFitnessPro"],
    cta: "Tag a friend who is intimidated by big commercial gyms!",
    category: "Vibe"
  },
  {
    day: 15,
    type: "Carousel",
    hook: "Beginner's 4-Week Gym Blueprint: Day 1 to Day 28 📅",
    caption: "Don't walk into the gym confused! Here is our exact 3-day full body split for week 1 to 4 with sets, reps, and rest periods. Handed to every new member at our reception.",
    hashtags: ["#WorkoutPlan", "#BeginnerWorkout", "#FullBodySplit", "#GymBlueprint", "#Sector52Gurugram", "#FitIndia", "#FitnessJourney", "#MyFitnessPro"],
    cta: "Save this post and claim your physical copy at our front desk!",
    category: "Trainer Tip"
  },
  {
    day: 16,
    type: "Story",
    hook: "Aerobics batch burning 550 kcal on a rainy evening 🌧️💃",
    caption: "Rain outside, pure fire inside the studio! Aerobics + toning with high-tempo tracks.",
    hashtags: ["#AerobicsClass", "#MonsoonWorkout", "#GurgaonRain", "#Sector52", "#ArdeeCity", "#FitnessFun", "#HealthyLiving", "#FitnessPro"],
    cta: "Drop an emoji: 🔥 if you never skip workout even in rain!",
    category: "Class Highlight"
  },
  {
    day: 17,
    type: "Reel",
    hook: "Dumbbell Bench Press: 3 Cues that will blow up your chest growth 💥",
    caption: "1. Retract shoulder blades. 2. 45-degree elbow tuck. 3. Squeeze at the top without banging the weights together. Save this for Monday chest day!",
    hashtags: ["#ChestDayTips", "#DumbbellPress", "#GymForm", "#Hypertrophy", "#Sector52", "#GurgaonLifters", "#WorkoutTips", "#MyFitnessPro"],
    cta: "Save this reel and try it on your next upper body session!",
    category: "Trainer Tip"
  },
  {
    day: 18,
    type: "Carousel",
    hook: "Priya Ji's Fitness Story: 'At 42, I feel lighter and more energetic than in my 20s' 🌸",
    caption: "Homemaker, mother of two, and now our most consistent 7 AM attendee. Read her inspiring routine balance between family, dance classes, and light strength work.",
    hashtags: ["#WomenWhoLift", "#GurgaonMoms", "#FitAt40", "#HomemakerFitness", "#Sector52", "#ArdeeCity", "#InspiringWomen", "#MyFitnessPro"],
    cta: "Leave some love for Priya Ji in the comments below! ❤️",
    category: "Transformation"
  },
  {
    day: 19,
    type: "Story",
    hook: "Question of the Day: What is your #1 fitness goal for this month? 🎯",
    caption: "Fat loss, muscle gain, stamina, or stress relief? Our trainers are replying to every response with 1 actionable tip!",
    hashtags: ["#FitnessGoals", "#AskTheTrainer", "#GurgaonFit", "#Sector52", "#ArdeeCity", "#GymCommunity", "#HealthGoals", "#MyFitnessPro"],
    cta: "Type your answer in the question sticker!",
    category: "Vibe"
  },
  {
    day: 20,
    type: "Reel",
    hook: "Ever wondered what a certified trainer eats in Gurugram? 🥗",
    caption: "A full day of eating with Coach Rahul. 130g protein, 100% vegetarian Indian staples, zero boring meals. Watch till the end for his secret evening protein shake recipe!",
    hashtags: ["#FullDayOfEating", "#TrainerDiet", "#VegetarianBodybuilding", "#GurgaonFitness", "#Sector52", "#FitIndia", "#DesiProtein", "#MyFitnessPro"],
    cta: "Share this reel with a vegetarian friend looking for protein!",
    category: "Trainer Tip"
  },
  {
    day: 21,
    type: "Carousel",
    hook: "Cardio vs Weights: Which burns fat faster for Gurugram professionals? ⚖️",
    caption: "Stop spending 60 minutes only on the treadmill! Learn the EPOC effect (afterburn) of combining 35 mins of strength training with 15 mins of high-intensity functional cardio.",
    hashtags: ["#CardioVsWeights", "#FatLossTruths", "#EPOC", "#GurugramFitness", "#Sector52", "#ArdeeCity", "#SmartTraining", "#MyFitnessPro"],
    cta: "Save this post and switch up your routine this week!",
    category: "Trainer Tip"
  },
  {
    day: 22,
    type: "Story",
    hook: "Spotted: 50kg dumbbell rack fully organized and ready! 🦾",
    caption: "Heavy lifters of Sector 52, your playground is waiting. Come test your personal best.",
    hashtags: ["#HeavyWeights", "#Dumbbells", "#StrengthFloor", "#Sector52", "#GurgaonGym", "#LiftingVibes", "#ArdeeCity", "#MyFitnessPro"],
    cta: "What dumbbell weight do you press? Reply to story!",
    category: "Vibe"
  },
  {
    day: 23,
    type: "Reel",
    hook: "Dance fitness choreography teaser: Desi Beats edition! 🎵",
    caption: "You don't need rhythm, you just need energy! Our dance fitness sessions are packed with smiles, sweats, and high vibes. Join Pooja every Tuesday and Thursday at 7:30 PM.",
    hashtags: ["#DesiBeats", "#DanceFitnessGurgaon", "#ZumbaIndia", "#Sector52", "#ArdeeCity", "#CardioDance", "#FitnessMotivation", "#MyFitnessPro"],
    cta: "Comment 'DANCE' to get an invite for the next trial class!",
    category: "Class Highlight"
  },
  {
    day: 24,
    type: "Carousel",
    hook: "The Real Reason Most People Quit Gym in Month 2 (And How We Fix It) 🧠",
    caption: "Lack of plan, soreness, and unrealistic expectations. At My Fitness Pro, our structured 30-day onboarding and weekly trainer check-ins ensure you stay on track.",
    hashtags: ["#GymConsistency", "#HabitBuilding", "#FitnessMindset", "#GurgaonFit", "#Sector52", "#ArdeeCity", "#NeverGiveUp", "#MyFitnessPro"],
    cta: "Save this reminder for days you don't feel like showing up!",
    category: "Trainer Tip"
  },
  {
    day: 25,
    type: "Story",
    hook: "Behind the scenes: Equipment servicing and cable tension test 🔧",
    caption: "Smooth pulleys, calibrated weights, and lubricated tracks. We inspect every station every Friday night so your Saturday lift is flawless.",
    hashtags: ["#GymMaintenance", "#TopQuality", "#SafeWorkout", "#Sector52Gurugram", "#ArdeeCity", "#MyFitnessPro", "#FitnessIndia", "#GymStandard"],
    cta: "Experience the smoothest machines in town—visit us today!",
    category: "Vibe"
  },
  {
    day: 26,
    type: "Reel",
    hook: "3 Signs you need a certified Personal Trainer right now 📋",
    caption: "1. Been lifting for 6 months with zero physical change. 2. Persistent shoulder or knee ache after squats. 3. Zero nutrition accountability. Let's fix it together!",
    hashtags: ["#PersonalTrainerGurgaon", "#Sector52", "#ArdeeCity", "#FitnessCoach", "#TransformationCoach", "#FormCorrection", "#FitGurgaon", "#MyFitnessPro"],
    cta: "DM 'COACH' for a free 15-minute fitness assessment with our head trainer!",
    category: "Trainer Tip"
  },
  {
    day: 27,
    type: "Carousel",
    hook: "Student Special: How Gurugram University students workout on a budget 🎓",
    caption: "College life is stressful. Blow off steam, build confidence, and stay sharp with our exclusive student membership packages starting at transparent rates.",
    hashtags: ["#StudentDiscount", "#CollegeFitness", "#GurgaonStudents", "#Sector52", "#ArdeeCity", "#AffordableGym", "#HealthyLifestyle", "#MyFitnessPro"],
    cta: "Show your valid college ID at the desk for an extra student perk!",
    category: "Vibe"
  },
  {
    day: 28,
    type: "Story",
    hook: "Saturday Morning CrossFit WOD Scoreboard 🏆",
    caption: "Shoutout to everyone who conquered the 20-minute AMRAP! Best team effort this month.",
    hashtags: ["#CrossFitCommunity", "#WOD", "#SaturdaySweat", "#GurgaonAthletes", "#Sector52", "#ArdeeCity", "#FitIndia", "#MyFitnessPro"],
    cta: "Double tap to salute the athletes!",
    category: "Class Highlight"
  },
  {
    day: 29,
    type: "Reel",
    hook: "Full 30-Second Tour of My Fitness Pro Gym, Ardee City Sector 52 🏢",
    caption: "CrossFit turf, free-weight floor, cardio deck, cycling studio, clean locker rooms, and certified coaching staff. Everything you need under one roof. Dekho aur batao kaisa laga!",
    hashtags: ["#GymTour", "#ArdeeCityGym", "#Sector52Gurugram", "#GymNearMe", "#BestGymInGurgaon", "#FitnessFacility", "#GurugramLife", "#MyFitnessPro"],
    cta: "Book your 1-day free trial through link in bio or WhatsApp!",
    category: "Vibe"
  },
  {
    day: 30,
    type: "Carousel",
    hook: "Next Month Challenge: Are you joining our 30-Day Shred? 🔥",
    caption: "New month, new commitment! 30 days of guided workouts, tailored diet plans, and community prizes. Limited to the first 25 sign-ups in Sector 52.",
    hashtags: ["#FitnessChallenge", "#30DayShred", "#GurgaonFitness", "#Sector52", "#ArdeeCity", "#WeightLossChallenge", "#TransformYourself", "#MyFitnessPro"],
    cta: "DM 'CHALLENGE' or visit front desk to secure your spot!",
    category: "Transformation"
  }
];

// 2. 5 Reel Scripts
export const REEL_SCRIPTS: ReelScript[] = [
  {
    id: "reel-crossfit",
    topic: "CrossFit Class High Energy",
    duration: "20 seconds",
    audioSuggestion: "Trending aggressive phonk or electronic drop (e.g., 'Metamorphosis' or heavy bass beat)",
    onScreenText: [
      "NOT YOUR AVERAGE WORKOUT ⚡",
      "Sector 52's Most Intense CrossFit Arena",
      "Battle Ropes · Kettlebells · Rowers",
      "Ready to push your limits?",
      "Book Free Trial at @myfitnesspro55"
    ],
    voiceover: "Tired of the same old boring treadmill routine? Step onto the CrossFit turf at My Fitness Pro Gym, Sector 52 Gurugram. High intensity, certified coaches, and pure adrenaline. Tag a friend who needs this push!",
    shotList: [
      { shot: "0-3s (Hook)", visual: "Close-up of chalk clapping in air, slow-mo cut to athlete slamming battle ropes with high energy." },
      { shot: "3-8s", visual: "Fast cuts: barbell clean & press, kettlebell swings, and athlete sprinting on assault bike." },
      { shot: "8-14s", visual: "Group cheering each other on during final countdown of WOD, coach clapping and motivating." },
      { shot: "14-20s (CTA)", visual: "Wide shot of spacious facility with sunset light, coach fist-bumping a member. On-screen text with logo and CTA." }
    ]
  },
  {
    id: "reel-dance",
    topic: "Dance Fitness & Zumba Class",
    duration: "25 seconds",
    audioSuggestion: "Trending upbeat Punjabi / Bollywood remix with heavy infectious rhythm",
    onScreenText: [
      "WHO SAID CARDIO HAS TO BE BORING? 💃",
      "500+ Calories Burned in 45 Mins",
      "Non-Stop Bollywood & Zumba Beats",
      "Safe & Welcoming for Women & Beginners",
      "DM 'DANCE' to join trial batch!"
    ],
    voiceover: "Agar cardio se bore ho chuke ho, then you haven't tried our Dance Fitness class yet! High energy Bollywood beats, zero judgment, and the happiest way to burn 500 calories in Gurugram. Come dance with us at My Fitness Pro!",
    shotList: [
      { shot: "0-3s (Hook)", visual: "Instructor smiling into camera, drops the beat with energetic shoulder shimmy and spin." },
      { shot: "3-10s", visual: "Wide studio view with vibrant ambient wash lights, 15+ members syncing footsteps and laughing." },
      { shot: "10-18s", visual: "Dynamic tracking shot moving along the front row of members having fun and sweating." },
      { shot: "18-25s (CTA)", visual: "Whole group raising hands and celebrating at the finish of song, instructor waving: 'Join us tomorrow!'" }
    ]
  },
  {
    id: "reel-trainer-day",
    topic: "Day in the Life of a Gym Trainer",
    duration: "30 seconds",
    audioSuggestion: "Chill lo-fi hip hop beat with smooth acoustic rhythm",
    onScreenText: [
      "DAY IN THE LIFE: Head Coach Vikram ⏱️",
      "05:15 AM: Facility Prep & Calibration",
      "06:30 AM: Morning Transformation Clients",
      "12:00 PM: Macro Meal Prep & Personal Lift",
      "06:00 PM: Form Checks & Posture Fixes",
      "Sector 52 Gurugram · My Fitness Pro Gym"
    ],
    voiceover: "A day in the life of a trainer at My Fitness Pro Gym! 5:15 AM: Arrive before everyone, inspect the weights, calibrate machines. 6:30 AM: Push our morning corporate warriors through their sets. Afternoon: Nutrition consultations and checking member food logs. 6 PM: Correcting squats and celebrating new personal bests. It's not just a job—it's our passion.",
    shotList: [
      { shot: "0-5s", visual: "Coach unlocking gym doors at dawn, switching on the warm lights, rolling out rubber mats." },
      { shot: "5-12s", visual: "Coach closely guiding a member's dumbbell bench press, gently adjusting elbow angle with encouragement." },
      { shot: "12-20s", visual: "Reviewing a customized Indian vegetarian diet chart on tablet with a client smiling." },
      { shot: "20-30s (CTA)", visual: "Evening buzz in gym, coach doing high-five with member. 'See you on the floor tomorrow!'" }
    ]
  },
  {
    id: "reel-beginner-tip",
    topic: "Free-Weights Beginner Tip (Avoid Injury)",
    duration: "20 seconds",
    audioSuggestion: "Trending snappy instructional voiceover style with subtle crisp background beats",
    onScreenText: [
      "DON'T RUIN YOUR SHOULDERS LIKE THIS 🛑",
      "Lateral Raise Mistake #1",
      "Wrong: Shrugging traps and swinging",
      "Right: Slight lean, pour the pitcher, lead with elbows",
      "Save for your next shoulder day! 📌"
    ],
    voiceover: "Stop doing lateral raises like this! When you swing the dumbbells with heavy momentum, your traps do all the work and your shoulder joint takes the beating. Instead: lean slightly forward, lead with your elbows, and control the way down. Try this at My Fitness Pro Gym!",
    shotList: [
      { shot: "0-4s", visual: "Trainer acting out the exaggerated wrong form with red 'X' graphic on screen." },
      { shot: "4-12s", visual: "Side-by-side comparison: green checkmark showing pristine form, relaxed neck, strict side-delt activation." },
      { shot: "12-16s", visual: "Close-up of side deltoid contracting smoothly under controlled load." },
      { shot: "16-20s (CTA)", visual: "Trainer smiling and pointing: 'Save this for your next workout, and ask us on the floor anytime!'" }
    ]
  },
  {
    id: "reel-gym-tour",
    topic: "360° Gym Tour of My Fitness Pro Gym",
    duration: "28 seconds",
    audioSuggestion: "Upbeat modern synth-pop or energetic commercial gym beat",
    onScreenText: [
      "WELCOME TO MY FITNESS PRO GYM 📍",
      "Ardee City, Sector 52, Gurugram",
      "⭐ 4.9 Rated (416 Google Reviews)",
      "Spacious Cardio · Heavy Free Weights · CrossFit Rig",
      "Clean Showers & Zero Crowding",
      "Plans start @ ₹499 · Book Free Trial Today!"
    ],
    voiceover: "Looking for the cleanest, most spacious gym in Sector 52 Gurugram? Welcome to My Fitness Pro Gym in Ardee City! Rated 4.9 stars by over 400 members. Here's what you get: spotless cardio zone, dumbbells up to 50kg, dedicated CrossFit turf, dance studio, and trainers who genuinely care. Affordable plans starting at just ₹499. Come experience the vibe!",
    shotList: [
      { shot: "0-4s", visual: "Smooth gimbal walkthrough entrance, reception desk, bright welcoming signage." },
      { shot: "4-10s", visual: "Wide sweeping pan of open-concept free weights area, pristine benches and polished floors." },
      { shot: "10-16s", visual: "Turf area with kettlebells and battle ropes, cutting to spinning and dance fitness studio." },
      { shot: "16-22s", visual: "Clean, hygienic changing rooms and showers with fresh towels." },
      { shot: "22-28s (CTA)", visual: "Coach and front desk team smiling: 'Ardee City, Sector 52. DM us for your free pass!'" }
    ]
  }
];

// 3. Google Review Replies (10 Positive + 3 Critical)
export const REVIEW_REPLIES: ReviewReply[] = [
  {
    id: 1,
    type: "positive",
    mentionKeyword: "Clean & Spacious Space",
    reviewSnippet: "Loved the hygiene! The gym is huge, well-ventilated, and machines are always sanitized.",
    replyText: "Thank you so much! Cleanliness and good air circulation are top priorities for us at My Fitness Pro Gym. We are thrilled you enjoy the spacious floor. Keep crushing your workouts in Sector 52!"
  },
  {
    id: 2,
    type: "positive",
    mentionKeyword: "Helpful & Supportive Trainers",
    reviewSnippet: "Trainers don't ignore you here! Coach Vikram guided my deadlift form patiently.",
    replyText: "Thank you for the kind words! Coach Vikram and our entire training team take immense pride in member safety and correct biomechanics. We are always right here on the floor for you!"
  },
  {
    id: 3,
    type: "positive",
    mentionKeyword: "Affordable & Transparent Pricing",
    reviewSnippet: "Best pricing in Ardee City with zero hidden fees. Got a great quarterly deal.",
    replyText: "We truly appreciate your review! Honest, transparent pricing without surprise registration charges is our core promise. Thank you for making My Fitness Pro your fitness home!"
  },
  {
    id: 4,
    type: "positive",
    mentionKeyword: "Well-Maintained Equipment",
    reviewSnippet: "Dumbbells are always racked, pulleys are smooth as butter, no broken machines.",
    replyText: "Thank you! Our maintenance team services and calibrates all equipment weekly so every rep feels crisp and safe. Great having you with us in Sector 52!"
  },
  {
    id: 5,
    type: "positive",
    mentionKeyword: "Custom Diet Plan",
    reviewSnippet: "The Indian vegetarian diet chart actually worked! Lost 4 kg without giving up roti or dal.",
    replyText: "Congratulations on the phenomenal progress! Sustainable Indian nutrition that fits your lifestyle is what we swear by. Keep up the consistency—we are super proud of your journey!"
  },
  {
    id: 6,
    type: "positive",
    mentionKeyword: "Dance Fitness & Aerobics",
    reviewSnippet: "Zumba classes with Pooja are the best part of my week. Fantastic crowd and energy.",
    replyText: "Thank you! Pooja's dance batches bring unmatched energy to Ardee City. So glad you look forward to every session. See you at tomorrow's beat drop!"
  },
  {
    id: 7,
    type: "positive",
    mentionKeyword: "CrossFit & Turf Area",
    reviewSnippet: "Proper bumper plates, rowers, and assault bike. Rare to find this setup in Sector 52.",
    replyText: "Thank you for recognizing our functional arena! We designed the turf specifically for athletes who want serious conditioning. Keep crushing those WODs!"
  },
  {
    id: 8,
    type: "positive",
    mentionKeyword: "Motivating Atmosphere",
    reviewSnippet: "The vibe here is electric. Great music and everyone is focused on getting better.",
    replyText: "Thank you! The positive, ego-free community our members build together is what makes My Fitness Pro special. We love having you train with us!"
  },
  {
    id: 9,
    type: "positive",
    mentionKeyword: "Locker Rooms & Showers",
    reviewSnippet: "Clean hot showers make it so easy to head straight to Cyber Hub office after morning workout.",
    replyText: "Thank you! We know how crucial seamless morning routines are for Gurugram professionals. Glad our facilities make your day smoother!"
  },
  {
    id: 10,
    type: "positive",
    mentionKeyword: "Beginner Friendly",
    reviewSnippet: "Was super nervous as a complete beginner, but staff made me feel welcome from day one.",
    replyText: "Welcome to the family! Every fitness journey begins with day one, and we are honored to support yours. Never hesitate to ask any trainer for help!"
  },
  {
    id: 11,
    type: "critical",
    mentionKeyword: "Peak Hour Waiting",
    reviewSnippet: "Gets quite busy between 7:30 PM and 8:30 PM on chest press and cable crossover.",
    replyText: "Hi there. Thank you for your honest feedback. We monitor floor density closely and are adding duplicate cable attachments to ease peak 8 PM flow. Please connect with our manager on your next visit so we can help optimize your workout slot."
  },
  {
    id: 12,
    type: "critical",
    mentionKeyword: "Air Conditioning Concern",
    reviewSnippet: "One of the AC units near the free weights was blowing warm air yesterday evening.",
    replyText: "We sincerely apologize for the discomfort. Our HVAC technicians inspected the unit this morning and the cooling has been fully restored. Please reach out to our front desk directly anytime so we can resolve things on the spot."
  },
  {
    id: 13,
    type: "critical",
    mentionKeyword: "Music Volume",
    reviewSnippet: "Music was slightly too loud during my morning stretching routine on Tuesday.",
    replyText: "Thank you for letting us know! We have calibrated our morning playlist volume to ensure a balanced, energizing yet comfortable environment. We appreciate you helping us improve."
  }
];

// 4. Google Business Profile Posts (8 Posts)
export const GBP_POSTS: GbpPost[] = [
  {
    id: 1,
    title: "New Member Kickstart Offer 💥",
    content: "Ready to start your fitness journey in Sector 52, Gurugram? Join My Fitness Pro Gym this month and get a complimentary 1-on-1 Indian Diet Consultation + InBody Scan worth ₹2,000! Clean space, top-tier equipment, and zero registration fees. Plans start from just ₹499.",
    ctaButton: "Get Offer"
  },
  {
    id: 2,
    title: "Updated Weekly Class Timetable 📅",
    content: "Our updated group fitness schedule is live! From high-energy CrossFit WODs at 6 AM and 6:30 PM to Bollywood Dance Cardio and Spin Cycling sprints, we have slots tailored for working pros and homemakers. Check out the schedule and book your mat today.",
    ctaButton: "Learn More"
  },
  {
    id: 3,
    title: "Trainer Spotlight: Coach Vikram 🏋️",
    content: "Meet Coach Vikram, our Senior Strength & Conditioning specialist. With 8+ years of certified experience, Vikram specializes in injury rehab, progressive overload, and postural alignment. Have questions on your squat or deadlift? Vikram is on the floor daily at Ardee City!",
    ctaButton: "Book"
  },
  {
    id: 4,
    title: "Nutrition Tip: Desi Protein Without Powders 🥗",
    content: "Trying to hit your protein targets as a vegetarian in Gurugram? Combine 100g low-fat paneer (18g protein) with boiled black chana salad and a glass of roasted sattu chaas for an easy 35g protein boost. Pick up our free 1-page Indian Veg Diet Handout at our front desk!",
    ctaButton: "Learn More"
  },
  {
    id: 5,
    title: "Festival Fitness Special: Diwali Shred 🔥",
    content: "Enjoy the festive sweets without the guilt! Join our 30-Day Pre-Festive Transformation Challenge at My Fitness Pro Gym. Includes structured HIIT circuits, custom portion-control meal plans, and community prizes. Limited to the first 20 sign-ups in Sector 52.",
    ctaButton: "Get Offer"
  },
  {
    id: 6,
    title: "Experience My Fitness Pro: Free Trial Day 🎟️",
    content: "Don't just take our 416 Google reviews for it—come test our facility for free! Experience our spacious workout floor, try any cardio or free-weight machine, and chat with our friendly trainers. Zero pressure, pure fitness.",
    ctaButton: "Book"
  },
  {
    id: 7,
    title: "Weekend Community Boot Camp ⚡",
    content: "Every Saturday at 8 AM, our functional turf transforms into an action-packed team circuit: battle ropes, tire flips, assault bike sprints, and core burners. Free for all active members and their guests. Bring your energy!",
    ctaButton: "Call Now"
  },
  {
    id: 8,
    title: "Monsoon Immunity & Indoor Cycling 🚴",
    content: "Rain outside? Keep your cardio uninterrupted inside our temperature-controlled indoor spin cycling studio in Ardee City. Burn 500+ calories while staying dry and listening to high-tempo tracks.",
    ctaButton: "Book"
  }
];

// 5. Ad Copy (Meta & Google Search)
export const AD_COPY_DATA: AdCopyItem[] = [
  {
    platform: "Meta",
    headline: "Top Gym in Sector 52 Gurugram",
    description: "4.9★ Rated on Google (416 Reviews). Clean space, CrossFit turf & certified trainers. Plans from ₹499 + Free Trial Pass!",
    targetAudience: "Working pros & college students aged 18-45 within 5km radius of Ardee City"
  },
  {
    platform: "Meta",
    headline: "Tired of Crowded Gyms?",
    description: "Experience spacious floors, zero bench queues & motivating vibes at My Fitness Pro Gym, Ardee City. Claim your free pass!",
    targetAudience: "Fitness enthusiasts dissatisfied with commercial gym crowding"
  },
  {
    platform: "Meta",
    headline: "Transform in 90 Days",
    description: "Personal training + customized Indian vegetarian diet plans in Sector 52 Gurugram. Proven member results. Enquire now!",
    targetAudience: "People searching for weight loss & personal training in Gurugram"
  },
  {
    platform: "Meta",
    headline: "Dance Fitness & Zumba Fun 💃",
    description: "High calorie burn, Bollywood beats & safe welcoming atmosphere for women in Ardee City. Book your free trial class today!",
    targetAudience: "Women & homemakers aged 22-45 interested in dance, aerobics, and cardio"
  },
  {
    platform: "Meta",
    headline: "Affordable Gym Plans from ₹499",
    description: "Zero hidden charges. Transparent student & quarterly packages at My Fitness Pro Gym Sector 52. Start your journey today!",
    targetAudience: "College students and young professionals seeking budget-friendly transparent fitness"
  },
  {
    platform: "Google",
    headline: "Gym in Gurugram Sector 52",
    description: "4.9★ on Google (416 Reviews). CrossFit, PT & Aerobics in Ardee City. Free Trial Day Available.",
    targetAudience: "Keywords: 'gym near me', 'gym in sector 52 gurugram', 'best gym ardee city'"
  },
  {
    platform: "Google",
    headline: "Personal Trainer Sector 52",
    description: "Certified 1-on-1 Coaches & Custom Indian Diet Plans. Plans starting at ₹499. Book Free Session.",
    targetAudience: "Keywords: 'personal trainer gurgaon', 'fitness coach sector 52', 'weight loss gym'"
  },
  {
    platform: "Google",
    headline: "CrossFit Gym in Gurugram",
    description: "Dedicated Functional Turf, Bumper Plates & Assault Bikes. 4.9★ Rated. Claim Your Free Pass.",
    targetAudience: "Keywords: 'crossfit gurugram', 'functional training gym near me', 'strength training sector 52'"
  },
  {
    platform: "Google",
    headline: "Zumba & Aerobics Classes",
    description: "High Energy Dance Cardio & Spin Cycling in Ardee City Gurugram. Morning & Evening Batches.",
    targetAudience: "Keywords: 'zumba classes near me', 'aerobics gurugram', 'dance fitness classes'"
  },
  {
    platform: "Google",
    headline: "Best Clean Gym in Ardee City",
    description: "Well-Maintained Machines, Spotless Showers & Zero Admission Fees. Visit Today or Call Now.",
    targetAudience: "Keywords: 'clean gym gurugram', 'ardee city fitness centre', 'top rated gym sector 52'"
  }
];

// 6. WhatsApp Follow-up Cadence
export const WHATSAPP_CADENCE: WhatsAppMessage[] = [
  {
    step: "Message 1",
    timing: "Same day (Within 2 hours of enquiry)",
    text: "Hi [Name]! Thanks for reaching out to My Fitness Pro Gym, Ardee City Sector 52. When would you like to drop by for a quick look around and a complimentary workout pass? - Coach Vikram",
    goal: "Instant warm intro & low-friction trial booking"
  },
  {
    step: "Message 2",
    timing: "Day 2 (Social proof & reassurance)",
    text: "Hey [Name]! Just wanted to share: 416+ Gurugram members rate us 4.9★ for our clean space and supportive trainers. Would you prefer a morning (6-9 AM) or evening (6-9 PM) slot to check out the gym?",
    goal: "Overcome hesitation with verified Google proof"
  },
  {
    step: "Message 3",
    timing: "Day 5 (Free trial day invitation)",
    text: "Hi [Name], we have reserved a 1-day complimentary pass for you this week! Come try our cardio, free weights, or CrossFit class. No commitment needed. Can I book this for tomorrow?",
    goal: "Direct trial activation with zero perceived risk"
  },
  {
    step: "Message 4",
    timing: "Day 8 (Urgency & limited offer)",
    text: "Hey [Name]! Quick heads-up: our limited [offer] with a free customized Indian Diet Plan ends this Saturday. Reply YES to lock in your discounted rate before spots fill up!",
    goal: "Final conversion push before archiving lead"
  }
];

// 7. 10 Creative Membership Offers & Campaigns
export const MEMBERSHIP_OFFERS: MembershipOffer[] = [
  {
    id: 1,
    title: "Buddy / Couple Power Pass",
    badge: "Most Popular",
    mechanics: "Join together with a friend, sibling, or spouse and receive a flat 20% discount on both 3-month or annual plans + 2 complimentary personal training buddy sessions.",
    targetAudience: "Couples, roommates, and gym buddies in Ardee City seeking mutual workout accountability.",
    promotionPlaybook: "Promote via Instagram Reels showing duo workout drills and WhatsApp broadcast: 'Tag your gym partner'."
  },
  {
    id: 2,
    title: "Corporate Wellness Corporate Pass",
    badge: "B2B Outreach",
    mechanics: "Provide 15% off for employees of Genpact, Google, American Express, and nearby Cyber City / Golf Course Road companies upon presenting company corporate ID.",
    targetAudience: "Working professionals aged 24-40 suffering from sedentary desk-job strain.",
    promotionPlaybook: "LinkedIn outreach, office building notice boards, and Google Search Ads targeting 'gym near Cyber City'."
  },
  {
    id: 3,
    title: "College Student Semester Pass",
    badge: "Youth Starter",
    mechanics: "Transparent ₹1,999/month or ₹4,999 quarterly pass upon showing valid college ID. Access during afternoon & off-peak hours (11 AM to 5 PM) with zero registration fees.",
    targetAudience: "Students from Gurugram University, Amity, and local colleges.",
    promotionPlaybook: "Campus ambassador referral rewards, Instagram memes, and affordable student pricing highlights."
  },
  {
    id: 4,
    title: "30-Day Pre-Festive Transformation Challenge",
    badge: "High Conversion",
    mechanics: "Entry fee includes 30 days full gym access + custom Indian diet chart + weekly body composition tracking. Top 3 transformations win a 3-month free membership extension.",
    targetAudience: "People wanting visible fat loss before Diwali, wedding season, or New Year.",
    promotionPlaybook: "Run countdown posters on Instagram, display leaderboards at reception, and send WhatsApp broadcast."
  },
  {
    id: 5,
    title: "Member Referral Cashback / Free Month",
    badge: "Organic Growth",
    mechanics: "For every friend a current member refers who signs up for 3+ months, the referring member gets 1 month added to their plan for FREE (or ₹1,000 credit).",
    targetAudience: "Loyal existing members who already love the clean space and trainers.",
    promotionPlaybook: "In-gym posters near water stations and WhatsApp message to all members on their 30th day."
  },
  {
    id: 6,
    title: "Early Bird Morning Warriors",
    badge: "Batch Optimization",
    mechanics: "Exclusive 15% off on annual plans for members who check in between 5:30 AM and 8:30 AM. Encourages healthy morning habits and balances evening rush.",
    targetAudience: "Early rising corporate executives and fitness purists.",
    promotionPlaybook: "Sunrise Instagram Stories showing the freshly sanitized floor and energetic 6 AM morning crowd."
  },
  {
    id: 7,
    title: "Homemaker Afternoon Dance & Tone Club",
    badge: "Community Focus",
    mechanics: "Special batch pricing for women between 11:30 AM and 1:30 PM with dedicated female trainers, low-impact aerobics, Zumba, and mobility sessions.",
    targetAudience: "Homemakers in Ardee City & Sector 52 seeking a safe, friendly, women-centric environment.",
    promotionPlaybook: "WhatsApp society groups, Ardee City resident associations, and flyer distribution."
  },
  {
    id: 8,
    title: "Annual Membership Freeze Guarantee",
    badge: "Zero-Risk Retention",
    mechanics: "Every 12-month membership includes up to 45 days of 'No-Questions-Asked' freeze privilege for business travel, vacations, or exams.",
    targetAudience: "Prospective members hesitant to commit to 12 months due to busy travel schedules.",
    promotionPlaybook: "Highlight on pricing table as objection-handling killer feature."
  },
  {
    id: 9,
    title: "Transformation PT Guaranteed Trial",
    badge: "High-Ticket PT",
    mechanics: "Book 3 private 1-on-1 sessions with our Senior Strength Coach + custom Indian diet assessment for ₹1,999. If they upgrade to a full PT package, the ₹1,999 is fully credited.",
    targetAudience: "Clients who need intensive help but are scared to commit ₹26k upfront.",
    promotionPlaybook: "Targeted Meta Lead Ads targeting 'personal trainer in Gurugram'."
  },
  {
    id: 10,
    title: "Weekend Warrior Family Pass",
    badge: "Lifestyle Package",
    mechanics: "Friday to Sunday access for busy executives + complimentary access to group sports and badminton/agility drills for their teenage children.",
    targetAudience: "Families in residential societies across Sector 52 looking for active weekend routines.",
    promotionPlaybook: "Weekend society booths and targeted local neighborhood Facebook groups."
  }
];
