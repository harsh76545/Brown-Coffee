import React, { useState } from 'react';
import { Star, CheckCircle, MessageSquare } from 'lucide-react';
import { REVIEWS_DATA, GYM_DETAILS, ReviewItem } from '../data/gymData';

export const ReviewsSection: React.FC = () => {
  const [selectedTag, setSelectedTag] = useState<string>('All');

  const tags = ['All', 'Cleanliness', 'Trainers', 'Equipment', 'Diet Plans', 'Atmosphere'];

  const filteredReviews = selectedTag === 'All'
    ? REVIEWS_DATA
    : REVIEWS_DATA.filter(r => r.tag === selectedTag);

  return (
    <section id="reviews" className="py-20 bg-neutral-950 border-b border-neutral-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with Claim-to-Proof */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-12">
          <div>
            <div className="text-xs uppercase tracking-widest text-amber-400 font-semibold mb-2">
              Verified Member Feedback
            </div>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold uppercase text-white tracking-tight">
              4.9 Stars Across 416 Google Reviews
            </h2>
          </div>

          {/* Aggregate Rating Scoreboard */}
          <div className="bg-neutral-900 p-4 sm:p-5 rounded-2xl border border-neutral-800 flex items-center gap-5 shrink-0">
            <div className="text-center">
              <div className="font-display text-4xl font-bold text-amber-400 tabular-nums">
                4.9
              </div>
              <div className="flex items-center gap-1 text-amber-400 mt-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                ))}
              </div>
            </div>
            <div className="text-xs text-neutral-400 border-l border-neutral-800 pl-4 space-y-1">
              <div className="text-white font-semibold">416 Verified Reviews</div>
              <div>Ardee City, Sector 52, Gurugram</div>
              <div className="text-emerald-400 font-medium">98% Positive Feedback</div>
            </div>
          </div>
        </div>

        {/* Tag Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 text-xs font-semibold">
          {tags.map(tag => (
            <button
              key={tag}
              onClick={() => setSelectedTag(tag)}
              className={`px-3.5 py-1.5 rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                selectedTag === tag
                  ? 'bg-amber-400 text-neutral-950 shadow-sm'
                  : 'bg-neutral-900 text-neutral-300 hover:text-white border border-neutral-800'
              }`}
            >
              {tag === 'All' ? 'All Reviews' : tag}
            </button>
          ))}
        </div>

        {/* Review Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredReviews.map((review, idx) => (
            <div
              key={idx}
              className="bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 rounded-2xl p-6 transition-all flex flex-col justify-between space-y-4"
            >
              <div>
                {/* Rating & Tag */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-1">
                    {[...Array(review.rating)].map((_, rIdx) => (
                      <Star key={rIdx} className="w-4 h-4 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  {/* Clean unboxed tag with separator */}
                  <span className="text-xs text-amber-400/90 font-medium">
                    {review.tag}
                  </span>
                </div>

                {/* Comment */}
                <p className="text-sm text-neutral-300 leading-relaxed italic">
                  &ldquo;{review.comment}&rdquo;
                </p>
              </div>

              {/* Reviewer Details */}
              <div className="pt-4 border-t border-neutral-800/80 flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-white flex items-center gap-1.5">
                    <span>{review.name}</span>
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                  <div className="text-neutral-500 mt-0.5">{review.role}</div>
                </div>
                <div className="text-neutral-500 font-mono text-[11px] tabular-nums">
                  {review.date}
                </div>
              </div>

            </div>
          ))}
        </div>

        {/* Google Reviews Direct Link Box */}
        <div className="mt-10 p-6 rounded-2xl bg-neutral-900/40 border border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs text-neutral-400">
          <div className="flex items-center gap-3">
            <MessageSquare className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <span className="text-white font-semibold">Have you trained with us at My Fitness Pro?</span>
              <span className="hidden sm:inline"> Share your fitness transformation on Google to help fellow Sector 52 residents.</span>
            </div>
          </div>
          <a
            href="https://www.google.com/maps/search/My+Fitness+Pro+Gym+Ardee+City+Sector+52+Gurugram"
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg font-semibold transition-colors shrink-0 text-center"
          >
            Review on Google
          </a>
        </div>

      </div>
    </section>
  );
};
