import React, { useState } from 'react';
import { CheckCircle2, Clock, Users, ArrowUpRight } from 'lucide-react';
import { SERVICES_DATA, ServiceItem } from '../data/gymData';

interface ServicesSectionProps {
  onSelectService: (service: ServiceItem) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectService }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const filteredServices = activeCategory === 'all' 
    ? SERVICES_DATA 
    : SERVICES_DATA.filter(s => s.category.toLowerCase().includes(activeCategory.toLowerCase()));

  return (
    <section id="services" className="py-20 bg-neutral-950 border-b border-neutral-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="text-xs uppercase tracking-widest text-amber-400 font-semibold mb-2">
              Comprehensive Training Facility
            </div>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold uppercase text-white tracking-tight">
              Disciplines Engineered For Real Results
            </h2>
          </div>
          <p className="text-sm sm:text-base text-neutral-400 max-w-md">
            From high-intensity CrossFit WODs to 1-on-1 biomechanical coaching and joyful Bollywood dance fitness, we cover every dimension of physical wellness.
          </p>
        </div>

        {/* Filter Tabs (Interactive filter controls allowed per §1.A) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 text-xs font-semibold">
          <button
            onClick={() => setActiveCategory('all')}
            className={`px-4 py-2 rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              activeCategory === 'all'
                ? 'bg-amber-400 text-neutral-950 shadow-sm'
                : 'bg-neutral-900 text-neutral-300 hover:text-white border border-neutral-800'
            }`}
          >
            All Programs
          </button>
          <button
            onClick={() => setActiveCategory('crossfit')}
            className={`px-4 py-2 rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              activeCategory === 'crossfit'
                ? 'bg-amber-400 text-neutral-950 shadow-sm'
                : 'bg-neutral-900 text-neutral-300 hover:text-white border border-neutral-800'
            }`}
          >
            CrossFit & Conditioning
          </button>
          <button
            onClick={() => setActiveCategory('personal')}
            className={`px-4 py-2 rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              activeCategory === 'personal'
                ? 'bg-amber-400 text-neutral-950 shadow-sm'
                : 'bg-neutral-900 text-neutral-300 hover:text-white border border-neutral-800'
            }`}
          >
            1-on-1 Personal Training
          </button>
          <button
            onClick={() => setActiveCategory('dance')}
            className={`px-4 py-2 rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              activeCategory === 'dance'
                ? 'bg-amber-400 text-neutral-950 shadow-sm'
                : 'bg-neutral-900 text-neutral-300 hover:text-white border border-neutral-800'
            }`}
          >
            Dance Fitness & Aerobics
          </button>
          <button
            onClick={() => setActiveCategory('diet')}
            className={`px-4 py-2 rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              activeCategory === 'diet'
                ? 'bg-amber-400 text-neutral-950 shadow-sm'
                : 'bg-neutral-900 text-neutral-300 hover:text-white border border-neutral-800'
            }`}
          >
            Indian Diet & Nutrition
          </button>
        </div>

        {/* Bento Grid: Varied column spans for visual weight */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredServices.map((service, index) => {
            const isMarquee = index === 0 || index === 1;
            return (
              <div
                key={service.id}
                className={`group rounded-xl border border-neutral-800 bg-neutral-900/80 hover:border-neutral-700 transition-all flex flex-col overflow-hidden ${
                  isMarquee && filteredServices.length > 3 ? 'md:col-span-1 lg:col-span-1' : ''
                }`}
              >
                {/* Visual Thumbnail */}
                <div className="relative aspect-16/10 overflow-hidden bg-neutral-950">
                  <img
                    src={service.image}
                    alt={service.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/30 to-transparent" />
                  
                  {/* Category unboxed tag */}
                  <div className="absolute top-3 left-3 text-xs font-semibold text-amber-300 bg-neutral-950/80 px-2.5 py-1 rounded border border-neutral-800">
                    {service.category}
                  </div>
                </div>

                {/* Card Content */}
                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div>
                    {/* Natural Editorial Numbering */}
                    <div className="text-xs font-semibold text-neutral-500 mb-1">
                      {String(index + 1).padStart(2, '0')}.
                    </div>
                    <h3 className="font-display text-xl font-bold uppercase text-white tracking-wide group-hover:text-amber-400 transition-colors">
                      {service.title}
                    </h3>
                    <p className="text-sm text-neutral-300 mt-2 leading-relaxed">
                      {service.description}
                    </p>
                  </div>

                  {/* Highlights */}
                  <div className="space-y-1.5 pt-2 border-t border-neutral-800/80">
                    {service.highlights.map((highlight, hIdx) => (
                      <div key={hIdx} className="flex items-start gap-2 text-xs text-neutral-400">
                        <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                        <span>{highlight}</span>
                      </div>
                    ))}
                  </div>

                  {/* Metadata and Action */}
                  <div className="pt-3 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400">
                    <div className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-neutral-500" />
                      <span className="truncate max-w-[170px]">{service.timing}</span>
                    </div>

                    <button
                      onClick={() => onSelectService(service)}
                      className="inline-flex items-center gap-1 font-semibold text-amber-400 hover:text-amber-300 transition-colors cursor-pointer"
                    >
                      <span>Details</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
