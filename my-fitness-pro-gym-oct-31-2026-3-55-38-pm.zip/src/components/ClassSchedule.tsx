import React, { useState } from 'react';
import { Calendar, Flame, UserCheck, ArrowRight } from 'lucide-react';
import { SCHEDULE_DATA, ClassScheduleItem } from '../data/gymData';

interface ClassScheduleProps {
  onReserve: (item: ClassScheduleItem) => void;
}

const DAYS_LIST = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] as const;

export const ClassSchedule: React.FC<ClassScheduleProps> = ({ onReserve }) => {
  const [selectedDay, setSelectedDay] = useState<typeof DAYS_LIST[number]>('Mon');

  const dayClasses = SCHEDULE_DATA.filter(item => item.days.includes(selectedDay));

  return (
    <section id="schedule" className="py-20 bg-neutral-900/40 border-b border-neutral-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <div className="text-xs uppercase tracking-widest text-amber-400 font-semibold mb-2">
              Weekly Studio Timetable
            </div>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold uppercase text-white tracking-tight">
              Group Energy. Individual Growth.
            </h2>
          </div>
          <p className="text-sm text-neutral-400 max-w-md">
            All classes are included in 3M+ memberships or accessible via a ₹499 Day Pass. Reserve your spot online or at the reception 15 minutes before batch start.
          </p>
        </div>

        {/* Day Selector Buttons */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8">
          {DAYS_LIST.map(day => (
            <button
              key={day}
              onClick={() => setSelectedDay(day)}
              className={`px-5 py-2.5 rounded-lg text-sm font-bold tracking-wide transition-all whitespace-nowrap cursor-pointer uppercase font-display ${
                selectedDay === day
                  ? 'bg-amber-400 text-neutral-950 shadow-md shadow-amber-400/20'
                  : 'bg-neutral-900 text-neutral-300 hover:text-white border border-neutral-800'
              }`}
            >
              {day === 'Mon' ? 'Monday' :
               day === 'Tue' ? 'Tuesday' :
               day === 'Wed' ? 'Wednesday' :
               day === 'Thu' ? 'Thursday' :
               day === 'Fri' ? 'Friday' :
               day === 'Sat' ? 'Saturday' : 'Sunday'}
            </button>
          ))}
        </div>

        {/* Schedule List */}
        <div className="space-y-3">
          {dayClasses.length === 0 ? (
            <div className="p-8 text-center bg-neutral-900/60 rounded-xl border border-neutral-800 text-neutral-400">
              No scheduled group classes on this day. The general free-weight floor and cardio deck remain open 7:00 AM – 8:00 PM.
            </div>
          ) : (
            dayClasses.map((item, idx) => (
              <div
                key={idx}
                className="bg-neutral-900/80 hover:bg-neutral-900 border border-neutral-800 hover:border-neutral-700 rounded-xl p-4 sm:p-5 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                {/* Time & Title */}
                <div className="flex items-start sm:items-center gap-4">
                  <div className="font-mono text-sm sm:text-base font-bold text-amber-400 tabular-nums shrink-0 w-36 sm:w-44">
                    {item.time}
                  </div>
                  <div>
                    <h4 className="font-display text-lg font-bold uppercase text-white tracking-wide">
                      {item.title}
                    </h4>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-400 mt-1">
                      <span>{item.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="flex items-center gap-1 text-neutral-300">
                        <UserCheck className="w-3.5 h-3.5 text-neutral-500" />
                        <span>{item.trainer}</span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Intensity & Reserve Action */}
                <div className="flex items-center justify-between md:justify-end gap-4 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-neutral-800">
                  <div className="flex items-center gap-1.5 text-xs">
                    <Flame className={`w-3.5 h-3.5 ${
                      item.intensity === 'Extreme' ? 'text-red-400' :
                      item.intensity === 'High' ? 'text-amber-400' : 'text-emerald-400'
                    }`} />
                    <span className="text-neutral-400">{item.intensity} Intensity</span>
                  </div>

                  <button
                    onClick={() => onReserve(item)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold uppercase tracking-wider text-neutral-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer"
                  >
                    <span>Reserve Mat</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Timetable Notice */}
        <div className="mt-8 p-4 rounded-xl bg-neutral-900/40 border border-neutral-800 text-xs text-neutral-400 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <span>
            📍 All classes held in Studio 1 & Turf Area, My Fitness Pro Gym, Ardee City Sector 52.
          </span>
          <span className="text-neutral-300">
            Lockers, showers & sanitized yoga mats provided complimentary.
          </span>
        </div>

      </div>
    </section>
  );
};
