import React, { useState } from 'react';
import { Sparkles, Menu, X, Phone, MessageSquare } from 'lucide-react';
import { GYM_DETAILS } from '../data/gymData';

interface NavbarProps {
  onOpenTrial: () => void;
  onOpenMarketingStudio: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenTrial, onOpenMarketingStudio }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-neutral-950/90 backdrop-blur-md border-b border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Bar Contract: Zone 1 (Wordmark) — Zone 2 (Nav links) — Zone 3 (Primary Action) */}
        <div className="flex items-center justify-between gap-8 h-20">
          
          {/* Zone 1: Single text element wordmark in display face */}
          <a href="#" className="font-display text-2xl sm:text-3xl font-bold tracking-wider text-white uppercase whitespace-nowrap shrink-0 hover:text-amber-400 transition-colors">
            MY FITNESS PRO
          </a>

          {/* Zone 2: 4-5 clean single-line nav links */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-neutral-300">
            <a href="#services" className="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0">Services</a>
            <a href="#schedule" className="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0">Class Timetable</a>
            <a href="#pricing" className="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0">Memberships</a>
            <a href="#handouts" className="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0">Diet & Workout</a>
            <a href="#reviews" className="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0">4.9★ Reviews</a>
            <a href="#location" className="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0">Sector 52 Location</a>
          </nav>

          {/* Zone 3: 1 Primary CTA Action + Marketing Toolkit Launcher */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenMarketingStudio}
              title="Open Marketing & AI Prompt Studio"
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-neutral-200 bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">AI Marketing Toolkit</span>
              <span className="sm:hidden">AI Hub</span>
            </button>

            <button
              onClick={onOpenTrial}
              className="px-4 py-2 sm:px-5 sm:py-2.5 text-xs sm:text-sm font-bold tracking-wide text-neutral-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-all shadow-sm hover:shadow-amber-500/20 whitespace-nowrap shrink-0 cursor-pointer uppercase"
            >
              Book Free Trial
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-neutral-400 hover:text-white rounded-lg focus:outline-none focus:ring-1 focus:ring-neutral-500"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-neutral-900 border-b border-neutral-800 px-4 pt-3 pb-6 space-y-3">
          <nav className="flex flex-col space-y-2 text-sm font-medium text-neutral-300">
            <a
              href="#services"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-md hover:bg-neutral-800 hover:text-white"
            >
              Services & Training
            </a>
            <a
              href="#schedule"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-md hover:bg-neutral-800 hover:text-white"
            >
              Weekly Class Timetable
            </a>
            <a
              href="#pricing"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-md hover:bg-neutral-800 hover:text-white"
            >
              Membership Pricing (from ₹499)
            </a>
            <a
              href="#handouts"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-md hover:bg-neutral-800 hover:text-white"
            >
              Indian Veg Diet & 4-Week Plan
            </a>
            <a
              href="#reviews"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-md hover:bg-neutral-800 hover:text-white"
            >
              Google Reviews (4.9 Rating)
            </a>
            <a
              href="#location"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-md hover:bg-neutral-800 hover:text-white"
            >
              Ardee City, Sector 52 Info
            </a>
          </nav>

          <div className="pt-3 border-t border-neutral-800 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenMarketingStudio();
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-neutral-200 bg-neutral-800 rounded-lg border border-neutral-700"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              Open Gym AI Prompt & Marketing Studio
            </button>
            <div className="flex items-center gap-2 pt-1 text-xs text-neutral-400 justify-center">
              <Phone className="w-3.5 h-3.5" />
              <span>{GYM_DETAILS.phone}</span>
              <span aria-hidden="true">·</span>
              <span>5:30 AM – 10:30 PM</span>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
