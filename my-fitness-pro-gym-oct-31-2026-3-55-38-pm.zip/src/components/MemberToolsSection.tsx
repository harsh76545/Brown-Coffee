import React, { useState } from 'react';
import { Apple, Dumbbell, Printer, Calculator, CheckSquare, Square, AlertCircle, Info } from 'lucide-react';
import { INDIAN_VEG_DIET_CHART, BEGINNER_WORKOUT_PLAN } from '../data/gymData';

export const MemberToolsSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'diet' | 'workout' | 'calculator'>('diet');
  const [completedExercises, setCompletedExercises] = useState<Record<string, boolean>>({});

  // Calculator state
  const [weightKg, setWeightKg] = useState<number>(70);
  const [heightCm, setHeightCm] = useState<number>(172);
  const [goal, setGoal] = useState<'fat_loss' | 'muscle_gain' | 'maintenance'>('fat_loss');

  const bmi = weightKg / Math.pow(heightCm / 100, 2);
  const maintenanceCalories = Math.round(weightKg * 22 * 1.4);
  const targetCalories = 
    goal === 'fat_loss' ? maintenanceCalories - 400 :
    goal === 'muscle_gain' ? maintenanceCalories + 300 : maintenanceCalories;
  const targetProtein = Math.round(weightKg * 1.8);

  const toggleExercise = (key: string) => {
    setCompletedExercises(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <section id="handouts" className="py-20 bg-neutral-900/40 border-b border-neutral-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <div className="text-xs uppercase tracking-widest text-amber-400 font-semibold mb-2">
              Member Handouts & Tools
            </div>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold uppercase text-white tracking-tight">
              Evidence-Based Indian Nutrition & Workouts
            </h2>
          </div>
          
          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors self-start md:self-auto cursor-pointer"
          >
            <Printer className="w-4 h-4 text-amber-400" />
            <span>Print / Save Handout</span>
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 p-1 bg-neutral-900 border border-neutral-800 rounded-xl mb-8 max-w-xl">
          <button
            onClick={() => setActiveTab('diet')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
              activeTab === 'diet'
                ? 'bg-amber-400 text-neutral-950 shadow-sm'
                : 'text-neutral-300 hover:text-white'
            }`}
          >
            <Apple className="w-4 h-4" />
            <span>Indian Veg Diet Chart</span>
          </button>
          <button
            onClick={() => setActiveTab('workout')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
              activeTab === 'workout'
                ? 'bg-amber-400 text-neutral-950 shadow-sm'
                : 'text-neutral-300 hover:text-white'
            }`}
          >
            <Dumbbell className="w-4 h-4" />
            <span>4-Week Beginner Plan</span>
          </button>
          <button
            onClick={() => setActiveTab('calculator')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
              activeTab === 'calculator'
                ? 'bg-amber-400 text-neutral-950 shadow-sm'
                : 'text-neutral-300 hover:text-white'
            }`}
          >
            <Calculator className="w-4 h-4" />
            <span>Target Calculator</span>
          </button>
        </div>

        {/* Tab 1: Indian Vegetarian Diet Chart */}
        {activeTab === 'diet' && (
          <div className="bg-neutral-900/70 border border-neutral-800 rounded-2xl p-6 sm:p-8 space-y-6">
            <div className="border-b border-neutral-800 pb-5">
              <div className="text-xs text-amber-400 font-semibold tracking-wide uppercase mb-1">
                Official Trainer Handout
              </div>
              <h3 className="font-display text-2xl font-bold uppercase text-white tracking-wide">
                {INDIAN_VEG_DIET_CHART.title}
              </h3>
              <p className="text-xs sm:text-sm text-neutral-400 mt-1">
                {INDIAN_VEG_DIET_CHART.subtitle} · <span className="text-neutral-300 font-medium">{INDIAN_VEG_DIET_CHART.macroSplit}</span>
              </p>
            </div>

            {/* Meal Cadence Grid */}
            <div className="space-y-4">
              {INDIAN_VEG_DIET_CHART.meals.map((meal, mIdx) => (
                <div
                  key={mIdx}
                  className="bg-neutral-950/60 border border-neutral-800/80 rounded-xl p-4 sm:p-5 flex flex-col md:flex-row md:items-start justify-between gap-4"
                >
                  <div className="md:w-52 shrink-0">
                    <span className="font-mono text-xs font-bold text-amber-400 bg-amber-400/10 px-2.5 py-1 rounded">
                      {meal.time}
                    </span>
                    <h4 className="font-semibold text-white text-sm mt-2">
                      {meal.phase}
                    </h4>
                  </div>

                  <div className="flex-1 space-y-1.5">
                    <p className="text-sm text-neutral-200 leading-relaxed font-medium">
                      {meal.items}
                    </p>
                    <p className="text-xs text-neutral-400">
                      💡 {meal.benefit}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Trainer Tips */}
            <div className="bg-neutral-950 p-5 rounded-xl border border-neutral-800 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                <Info className="w-4 h-4" />
                <span>Nutritionist Golden Rules for Gurugram Members</span>
              </h4>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-neutral-300">
                {INDIAN_VEG_DIET_CHART.trainerTips.map((tip, tIdx) => (
                  <li key={tIdx} className="flex items-start gap-2">
                    <span className="text-amber-400">•</span>
                    <span>{tip}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Disclaimer */}
            <div className="flex items-start gap-2 text-xs text-neutral-500 pt-2 border-t border-neutral-800/80">
              <AlertCircle className="w-4 h-4 text-neutral-500 shrink-0 mt-0.5" />
              <span>{INDIAN_VEG_DIET_CHART.disclaimer}</span>
            </div>
          </div>
        )}

        {/* Tab 2: 4-Week Beginner Workout Plan */}
        {activeTab === 'workout' && (
          <div className="bg-neutral-900/70 border border-neutral-800 rounded-2xl p-6 sm:p-8 space-y-6">
            <div className="border-b border-neutral-800 pb-5">
              <div className="text-xs text-amber-400 font-semibold tracking-wide uppercase mb-1">
                Structured Strength Progression
              </div>
              <h3 className="font-display text-2xl font-bold uppercase text-white tracking-wide">
                {BEGINNER_WORKOUT_PLAN.title}
              </h3>
              <p className="text-xs sm:text-sm text-neutral-400 mt-1">
                {BEGINNER_WORKOUT_PLAN.subtitle}
              </p>
            </div>

            {/* Week 1 Detailed Exercises with interactive checkoff */}
            <div className="space-y-6">
              <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 flex items-center justify-between">
                <div>
                  <span className="text-xs text-amber-400 font-bold uppercase">Week 1 Deep Dive</span>
                  <h4 className="font-bold text-white text-base">
                    {BEGINNER_WORKOUT_PLAN.weeks[0].theme}
                  </h4>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    {BEGINNER_WORKOUT_PLAN.weeks[0].focus}
                  </p>
                </div>
                <div className="text-xs font-semibold text-neutral-400 hidden sm:block">
                  Click checkbox as you complete reps
                </div>
              </div>

              {BEGINNER_WORKOUT_PLAN.weeks[0].days?.map((dayPlan, dIdx) => (
                <div key={dIdx} className="border border-neutral-800 rounded-xl overflow-hidden bg-neutral-950/40">
                  <div className="bg-neutral-800/50 px-4 py-2.5 flex items-center justify-between border-b border-neutral-800">
                    <div className="font-display text-base font-bold text-white uppercase tracking-wide">
                      {dayPlan.day} — {dayPlan.name}
                    </div>
                    <span className="text-xs text-amber-400 font-semibold">6 Exercises</span>
                  </div>

                  <div className="divide-y divide-neutral-800/60 p-2 sm:p-4 space-y-2">
                    {dayPlan.exercises.map((ex, exIdx) => {
                      const key = `${dIdx}-${exIdx}`;
                      const isDone = !!completedExercises[key];
                      return (
                        <div
                          key={exIdx}
                          onClick={() => toggleExercise(key)}
                          className={`p-3 rounded-lg flex items-center justify-between gap-3 cursor-pointer transition-colors ${
                            isDone ? 'bg-amber-400/10 text-neutral-400' : 'hover:bg-neutral-800/50 text-neutral-200'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            {isDone ? (
                              <CheckSquare className="w-5 h-5 text-amber-400 shrink-0" />
                            ) : (
                              <Square className="w-5 h-5 text-neutral-500 shrink-0" />
                            )}
                            <span className={`text-sm font-semibold ${isDone ? 'line-through text-neutral-400' : 'text-white'}`}>
                              {ex.name}
                            </span>
                          </div>

                          <div className="flex items-center gap-3 text-xs text-neutral-400 font-mono tabular-nums shrink-0">
                            <span className="bg-neutral-800 px-2 py-0.5 rounded text-neutral-300">{ex.sets}</span>
                            <span>{ex.reps}</span>
                            <span className="hidden sm:inline text-neutral-500">Rest: {ex.rest}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}

              {/* Weeks 2, 3, 4 Roadmap summary */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-neutral-800">
                {BEGINNER_WORKOUT_PLAN.weeks.slice(1).map((week, wIdx) => (
                  <div key={wIdx} className="bg-neutral-950 p-4 rounded-xl border border-neutral-800">
                    <div className="text-xs text-amber-400 font-bold uppercase mb-1">
                      Week {week.weekNumber} Progression
                    </div>
                    <div className="font-semibold text-white text-sm mb-1">
                      {week.theme}
                    </div>
                    <p className="text-xs text-neutral-400">
                      {week.focus}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <div className="text-xs text-neutral-500 pt-2 border-t border-neutral-800">
              * Trainers on duty at My Fitness Pro Gym are always available to check your form on compound movements (Squats, Bench Press, Deadlifts) free of cost.
            </div>
          </div>
        )}

        {/* Tab 3: BMI & Calorie Target Calculator */}
        {activeTab === 'calculator' && (
          <div className="bg-neutral-900/70 border border-neutral-800 rounded-2xl p-6 sm:p-8 space-y-6 max-w-3xl mx-auto">
            <div className="border-b border-neutral-800 pb-4">
              <h3 className="font-display text-2xl font-bold uppercase text-white tracking-wide">
                Fitness Target Estimator
              </h3>
              <p className="text-xs sm:text-sm text-neutral-400 mt-1">
                Calculate your Body Mass Index (BMI), daily calorie baseline, and daily protein targets.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              <div>
                <label className="block text-xs font-semibold uppercase text-neutral-400 mb-1.5">
                  Body Weight (kg)
                </label>
                <input
                  type="number"
                  value={weightKg}
                  onChange={(e) => setWeightKg(Math.max(30, Number(e.target.value)))}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-neutral-400 mb-1.5">
                  Height (cm)
                </label>
                <input
                  type="number"
                  value={heightCm}
                  onChange={(e) => setHeightCm(Math.max(100, Number(e.target.value)))}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-neutral-400 mb-1.5">
                  Primary Goal
                </label>
                <select
                  value={goal}
                  onChange={(e) => setGoal(e.target.value as any)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-amber-400"
                >
                  <option value="fat_loss">Fat Loss (-400 kcal)</option>
                  <option value="muscle_gain">Lean Muscle (+300 kcal)</option>
                  <option value="maintenance">Maintenance & Stamina</option>
                </select>
              </div>
            </div>

            {/* Results Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-neutral-800">
              <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 text-center">
                <div className="text-xs text-neutral-400 uppercase font-semibold">Your BMI</div>
                <div className="font-display text-3xl font-bold text-amber-400 mt-1 tabular-nums">
                  {bmi.toFixed(1)}
                </div>
                <div className="text-xs text-neutral-400 mt-1">
                  {bmi < 18.5 ? 'Underweight' : bmi < 25 ? 'Normal range' : bmi < 30 ? 'Overweight' : 'Obese range'}
                </div>
              </div>

              <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 text-center">
                <div className="text-xs text-neutral-400 uppercase font-semibold">Target Daily Calories</div>
                <div className="font-display text-3xl font-bold text-white mt-1 tabular-nums">
                  {targetCalories} <span className="text-sm font-sans font-normal text-neutral-400">kcal</span>
                </div>
                <div className="text-xs text-neutral-400 mt-1">
                  Based on moderate daily gym training
                </div>
              </div>

              <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 text-center">
                <div className="text-xs text-neutral-400 uppercase font-semibold">Target Daily Protein</div>
                <div className="font-display text-3xl font-bold text-amber-400 mt-1 tabular-nums">
                  {targetProtein} <span className="text-sm font-sans font-normal text-neutral-400">grams</span>
                </div>
                <div className="text-xs text-neutral-400 mt-1">
                  ~1.8g per kg bodyweight
                </div>
              </div>
            </div>

          </div>
        )}

      </div>
    </section>
  );
};
