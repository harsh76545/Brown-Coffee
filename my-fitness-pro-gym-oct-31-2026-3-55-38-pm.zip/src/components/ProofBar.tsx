import React from 'react';

export const ProofBar: React.FC = () => {
  return (
    <section className="bg-neutral-900/60 border-b border-neutral-800 py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center divide-y md:divide-y-0 md:divide-x divide-neutral-800">
          
          <div className="pt-2 md:pt-0">
            <div className="font-display text-3xl sm:text-4xl font-bold text-amber-400 tabular-nums">
              4.9 ★
            </div>
            <div className="text-xs sm:text-sm text-neutral-400 mt-1">
              416 Verified Google Reviews
            </div>
          </div>

          <div className="pt-4 md:pt-0">
            <div className="font-display text-3xl sm:text-4xl font-bold text-white tabular-nums">
              ₹499
            </div>
            <div className="text-xs sm:text-sm text-neutral-400 mt-1">
              Trial Day Pass · Plans to ₹26,990
            </div>
          </div>

          <div className="pt-4 md:pt-0">
            <div className="font-display text-3xl sm:text-4xl font-bold text-amber-400 tabular-nums">
              7+
            </div>
            <div className="text-xs sm:text-sm text-neutral-400 mt-1">
              CrossFit, PT, Dance, Spin & Yoga
            </div>
          </div>

          <div className="pt-4 md:pt-0">
            <div className="font-display text-3xl sm:text-4xl font-bold text-white tabular-nums">
              100%
            </div>
            <div className="text-xs sm:text-sm text-neutral-400 mt-1">
              Custom Indian Nutrition & Form Checks
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
