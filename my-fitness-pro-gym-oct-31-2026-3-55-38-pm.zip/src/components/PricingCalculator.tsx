import React, { useState } from 'react';
import { Check, Shield, Sparkles, Users, GraduationCap, ArrowRight } from 'lucide-react';
import { PRICING_PLANS, PricingPlan } from '../data/gymData';

interface PricingCalculatorProps {
  onSelectPlan: (plan: PricingPlan, discountType: 'standard' | 'student' | 'couple') => void;
}

export const PricingCalculator: React.FC<PricingCalculatorProps> = ({ onSelectPlan }) => {
  const [discountType, setDiscountType] = useState<'standard' | 'student' | 'couple'>('standard');

  const calculatePrice = (basePrice: number, planId: string) => {
    if (planId === 'day-pass') return basePrice;
    if (discountType === 'student') {
      return Math.round(basePrice * 0.85); // 15% student concession
    }
    if (discountType === 'couple') {
      return Math.round(basePrice * 0.80); // 20% buddy discount per person
    }
    return basePrice;
  };

  return (
    <section id="pricing" className="py-20 bg-neutral-950 border-b border-neutral-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="text-xs uppercase tracking-widest text-amber-400 font-semibold mb-2">
            100% Transparent Memberships
          </div>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold uppercase text-white tracking-tight">
            Flexible Passes Starting from ₹499
          </h2>
          <p className="text-sm sm:text-base text-neutral-400 mt-3">
            No surprise registration charges. No aggressive hard-selling. Choose the frequency that fits your routine in Gurugram, from single-day passes to all-inclusive 1-on-1 PT packages.
          </p>

          {/* Interactive Discount Selector */}
          <div className="inline-flex items-center gap-1 p-1 bg-neutral-900 border border-neutral-800 rounded-xl mt-6">
            <button
              onClick={() => setDiscountType('standard')}
              className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer ${
                discountType === 'standard'
                  ? 'bg-amber-400 text-neutral-950 shadow-sm'
                  : 'text-neutral-300 hover:text-white'
              }`}
            >
              Standard Rates
            </button>
            <button
              onClick={() => setDiscountType('student')}
              className={`flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer ${
                discountType === 'student'
                  ? 'bg-amber-400 text-neutral-950 shadow-sm'
                  : 'text-neutral-300 hover:text-white'
              }`}
            >
              <GraduationCap className="w-4 h-4" />
              <span>Student Pass (-15%)</span>
            </button>
            <button
              onClick={() => setDiscountType('couple')}
              className={`flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer ${
                discountType === 'couple'
                  ? 'bg-amber-400 text-neutral-950 shadow-sm'
                  : 'text-neutral-300 hover:text-white'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Buddy / Couple (-20%)</span>
            </button>
          </div>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {PRICING_PLANS.map((plan) => {
            const finalPrice = calculatePrice(plan.price, plan.id);
            const isDiscounted = finalPrice !== plan.price;

            return (
              <div
                key={plan.id}
                className={`rounded-2xl border transition-all flex flex-col justify-between p-6 sm:p-7 relative ${
                  plan.popular
                    ? 'bg-neutral-900/90 border-amber-400/80 shadow-lg shadow-amber-400/5'
                    : 'bg-neutral-900/50 border-neutral-800 hover:border-neutral-700'
                }`}
              >
                {/* Popular / Best Value Banner */}
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-amber-400 text-neutral-950 text-xs font-bold uppercase tracking-wider px-3.5 py-0.5 rounded-full shadow-sm">
                    Most Popular Choice
                  </div>
                )}

                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <h3 className="font-display text-xl sm:text-2xl font-bold uppercase text-white tracking-wide">
                      {plan.name}
                    </h3>
                    {plan.savings && (
                      <span className="text-xs font-semibold text-emerald-400">
                        {plan.savings}
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-neutral-400 leading-relaxed mb-6 min-h-[36px]">
                    {plan.description}
                  </p>

                  {/* Price Block */}
                  <div className="mb-6 pb-6 border-b border-neutral-800">
                    <div className="flex items-baseline gap-2">
                      <span className="font-display text-4xl sm:text-5xl font-bold text-white tabular-nums">
                        ₹{finalPrice.toLocaleString('en-IN')}
                      </span>
                      {isDiscounted && (
                        <span className="text-sm text-neutral-500 line-through tabular-nums">
                          ₹{plan.price.toLocaleString('en-IN')}
                        </span>
                      )}
                      <span className="text-xs text-neutral-400 font-medium">
                        / {plan.period}
                      </span>
                    </div>

                    {discountType !== 'standard' && plan.id !== 'day-pass' && (
                      <div className="text-xs text-amber-400 font-medium mt-1">
                        Applied: {discountType === 'student' ? 'Student 15% Concession' : 'Couple / Buddy 20% Discount'}
                      </div>
                    )}
                  </div>

                  {/* Features List */}
                  <div className="space-y-3 mb-8">
                    <div className="text-xs uppercase tracking-wider font-semibold text-neutral-400">
                      What&apos;s Included:
                    </div>
                    {plan.features.map((feature, fIdx) => (
                      <div key={fIdx} className="flex items-start gap-2.5 text-xs sm:text-sm text-neutral-300">
                        <Check className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Plan CTA Action */}
                <button
                  onClick={() => onSelectPlan(plan, discountType)}
                  className={`w-full py-3 px-4 rounded-xl text-xs sm:text-sm font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    plan.popular
                      ? 'bg-amber-400 hover:bg-amber-300 text-neutral-950 shadow-md shadow-amber-400/20'
                      : 'bg-neutral-800 hover:bg-neutral-700 text-white'
                  }`}
                >
                  <span>Select & Get Free Trial</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

              </div>
            );
          })}
        </div>

        {/* Transparent Pricing Guarantees */}
        <div className="mt-12 p-6 rounded-2xl bg-neutral-900/40 border border-neutral-800 grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-neutral-400">
          <div className="flex items-start gap-3">
            <Shield className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <div className="font-semibold text-white mb-0.5">Zero Hidden Admissions</div>
              <div>The price you see is the final price. No unexpected registration or locker rental fees.</div>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <div className="font-semibold text-white mb-0.5">45-Day Freeze Privilege</div>
              <div>Available on all 12-month memberships for travel, exams, or corporate relocations.</div>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Users className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <div className="font-semibold text-white mb-0.5">Complementary Diet Consultation</div>
              <div>Every 3-month and above plan includes a personalized Indian nutrition roadmap.</div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
