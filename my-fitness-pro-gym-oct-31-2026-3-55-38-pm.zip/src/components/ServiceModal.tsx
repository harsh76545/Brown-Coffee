import React from 'react';
import { X, CheckCircle2, Clock, Users, ArrowRight } from 'lucide-react';
import { ServiceItem } from '../data/gymData';

interface ServiceModalProps {
  service: ServiceItem | null;
  onClose: () => void;
  onBookTrial: () => void;
}

export const ServiceModal: React.FC<ServiceModalProps> = ({ service, onClose, onBookTrial }) => {
  if (!service) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div 
        className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-xl overflow-hidden relative shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 text-white/80 hover:text-white bg-black/50 hover:bg-black/80 rounded-full transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Image */}
        <div className="relative aspect-16/9 bg-neutral-950">
          <img
            src={service.image}
            alt={service.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 via-neutral-900/40 to-transparent" />
          
          <div className="absolute bottom-4 left-6">
            <span className="text-xs font-semibold text-amber-400 bg-neutral-950/80 px-2.5 py-1 rounded border border-neutral-800">
              {service.category}
            </span>
            <h3 className="font-display text-2xl sm:text-3xl font-bold uppercase text-white tracking-wide mt-1.5">
              {service.title}
            </h3>
          </div>
        </div>

        {/* Modal Content */}
        <div className="p-6 sm:p-7 space-y-5">
          <p className="text-sm text-neutral-300 leading-relaxed">
            {service.description}
          </p>

          <div className="space-y-2">
            <div className="text-xs font-semibold uppercase text-neutral-400 tracking-wider">
              Program Highlights:
            </div>
            {service.highlights.map((h, i) => (
              <div key={i} className="flex items-start gap-2.5 text-xs sm:text-sm text-neutral-200">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>{h}</span>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-3 pt-3 border-t border-neutral-800 text-xs">
            <div className="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
              <span className="text-neutral-500 block">Class Timings</span>
              <span className="font-semibold text-white mt-0.5 block">{service.timing}</span>
            </div>
            <div className="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
              <span className="text-neutral-500 block">Target Audience</span>
              <span className="font-semibold text-white mt-0.5 block">{service.idealFor}</span>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-neutral-400 hover:text-white transition-colors cursor-pointer"
            >
              Close
            </button>
            <button
              onClick={() => {
                onClose();
                onBookTrial();
              }}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-neutral-950 text-xs font-bold uppercase tracking-wider transition-all shadow-sm cursor-pointer"
            >
              <span>Book Trial Session</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
