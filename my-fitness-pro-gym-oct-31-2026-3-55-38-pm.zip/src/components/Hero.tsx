import React from 'react';
import { Star, ShieldCheck, ArrowRight, MapPin, Dumbbell } from 'lucide-react';
import { GYM_DETAILS } from '../data/gymData';

interface HeroProps {
  onOpenTrial: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenTrial }) => {
  return (
    <section className="relative overflow-hidden bg-neutral-950 pt-8 pb-16 lg:py-20 border-b border-neutral-900">
      {/* Background ambient radial glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-amber-500/10 blur-[130px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Column: Headlines & Call to Action */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Unboxed Metadata Trust Bar (Zero-Pill Discipline) */}
            <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm text-neutral-400 font-medium tracking-wide">
              <span className="flex items-center gap-1 text-amber-400 font-bold">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                <span>4.9 / 5.0 Rating</span>
              </span>
              <span aria-hidden="true" className="text-neutral-600">·</span>
              <span className="text-neutral-300">416 Verified Google Reviews</span>
              <span aria-hidden="true" className="text-neutral-600">·</span>
              <span className="flex items-center gap-1 text-neutral-300">
                <MapPin className="w-3.5 h-3.5 text-amber-400" />
                <span>Sector 52, Gurugram</span>
              </span>
            </div>

            {/* Display Headline */}
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white uppercase leading-[1.05] text-balance">
              Train with Purpose. <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-200 to-white">
                Transform in Sector 52.
              </span>
            </h1>

            {/* Subheading / Value Proposition */}
            <p className="text-base sm:text-lg text-neutral-300 leading-relaxed max-w-2xl">
              Ardee City&apos;s premier high-energy fitness destination. Clean, spacious training floors, certified coaches who prioritize injury-free biomechanics, dedicated CrossFit turf, vibrant dance classes, and sustainable Indian nutrition plans.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 pt-2">
              <button
                onClick={onOpenTrial}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-bold text-neutral-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-all shadow-md shadow-amber-400/20 uppercase tracking-wide cursor-pointer"
              >
                <span>Claim 1-Day Free Trial Pass</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <a
                href="#pricing"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-neutral-200 hover:text-white bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded-lg transition-colors"
              >
                <span>View Plans (From ₹499)</span>
              </a>
            </div>

            {/* Proof Badges List (Unboxed clean inline metadata) */}
            <div className="pt-4 border-t border-neutral-900 grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs text-neutral-400">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Zero Hidden Fees</span>
              </div>
              <div className="flex items-center gap-2">
                <Dumbbell className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Dumbbells up to 50kg</span>
              </div>
              <div className="flex items-center gap-2 col-span-2 sm:col-span-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                <span>Open 5:30 AM – 10:30 PM</span>
              </div>
            </div>

          </div>

          {/* Right Column: Hero Visual Asset (High fidelity image generated for this gym) */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-neutral-800 shadow-2xl bg-neutral-900 group">
              <img
                src="/src/assets/images/gym_hero_main_1793441842625.jpg"
                alt="My Fitness Pro Gym modern clean facility in Ardee City Sector 52 Gurugram"
                referrerPolicy="no-referrer"
                className="w-full h-auto aspect-16/10 object-cover object-center transition-transform duration-700 group-hover:scale-105"
              />

              {/* Contrast Scrim */}
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/20 to-transparent" />

              {/* Bottom Card Overlay: Real Location Proof */}
              <div className="absolute bottom-0 inset-x-0 p-5 space-y-1.5">
                <div className="flex items-center justify-between text-xs text-neutral-300">
                  <span className="font-semibold text-amber-400">Ardee City · Sector 52</span>
                  <span className="text-neutral-400">Near Ardee Mall</span>
                </div>
                <p className="text-sm font-medium text-white">
                  Spacious cardio deck, Olympic lifting turf & spotless shower amenities
                </p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
