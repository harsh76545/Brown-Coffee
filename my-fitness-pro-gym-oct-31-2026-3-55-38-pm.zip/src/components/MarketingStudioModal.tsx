import React, { useState } from 'react';
import { 
  X, Copy, Check, Sparkles, Instagram, Video, Star, Share2, 
  Megaphone, MessageSquare, Tag, Image as ImageIcon, Search, 
  FileText, ExternalLink, Printer, Sliders, Play, Eye
} from 'lucide-react';
import { 
  MARKETING_STUDIO_DATA, 
  INDIAN_VEG_DIET_CHART, 
  BEGINNER_WORKOUT_PLAN,
  GYM_DETAILS 
} from '../data/gymData';
import { 
  INSTAGRAM_30_DAYS, 
  REEL_SCRIPTS, 
  REVIEW_REPLIES, 
  GBP_POSTS, 
  AD_COPY_DATA, 
  WHATSAPP_CADENCE, 
  MEMBERSHIP_OFFERS 
} from '../data/marketingOutputs';

interface MarketingStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MarketingStudioModal: React.FC<MarketingStudioModalProps> = ({ isOpen, onClose }) => {
  const [activeModule, setActiveModule] = useState<string>('instagram-calendar');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [customOffer, setCustomOffer] = useState<string>('Flat 20% Off on 3-Month Plan + Free Diet Chart');
  const [customName, setCustomName] = useState<string>('Rohit');
  
  // Instagram filter
  const [instaFilter, setInstaFilter] = useState<'All' | 'Reel' | 'Carousel' | 'Story'>('All');
  
  // Reel teleprompter
  const [selectedReelId, setSelectedReelId] = useState<string>('reel-crossfit');

  // Ad Platform filter
  const [adPlatform, setAdPlatform] = useState<'All' | 'Meta' | 'Google'>('All');

  // Copy helper
  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  if (!isOpen) return null;

  const currentModule = MARKETING_STUDIO_DATA.modules.find(m => m.id === activeModule) || MARKETING_STUDIO_DATA.modules[0];

  const filteredInsta = instaFilter === 'All' 
    ? INSTAGRAM_30_DAYS 
    : INSTAGRAM_30_DAYS.filter(p => p.type === instaFilter);

  const selectedReel = REEL_SCRIPTS.find(r => r.id === selectedReelId) || REEL_SCRIPTS[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-md animate-fade-in">
      <div 
        className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-6xl h-[92vh] flex flex-col overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header Bar */}
        <div className="px-6 py-4 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-amber-400 text-neutral-950">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs uppercase font-bold text-amber-400 tracking-wider">
                My Fitness Pro Gym · Sector 52 Gurugram
              </div>
              <h2 className="font-display text-xl sm:text-2xl font-bold uppercase text-white tracking-wide">
                AI Marketing & Prompt Studio
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleCopy(MARKETING_STUDIO_DATA.businessContext, 'biz-context')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 transition-colors cursor-pointer"
              title="Copy the master business context block to paste at the start of ChatGPT or Claude"
            >
              {copiedId === 'biz-context' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-amber-400" />}
              <span>{copiedId === 'biz-context' ? 'Context Copied!' : 'Copy Master Context'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Global Parameter Bar: Customize [offer] and [name] */}
        <div className="px-6 py-2.5 bg-neutral-950/80 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-4 text-xs shrink-0">
          <div className="flex items-center gap-2 text-neutral-400">
            <Sliders className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-semibold text-neutral-300">Live Prompt Replacements:</span>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span className="text-neutral-400 font-mono">[offer]:</span>
              <input
                type="text"
                value={customOffer}
                onChange={(e) => setCustomOffer(e.target.value)}
                className="bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1 text-xs text-amber-300 w-64 focus:outline-none focus:border-amber-400"
                placeholder="e.g. Free Diet Chart + 20% Off"
              />
            </div>

            <div className="flex items-center gap-1.5">
              <span className="text-neutral-400 font-mono">[name]:</span>
              <input
                type="text"
                value={customName}
                onChange={(e) => setCustomName(e.target.value)}
                className="bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1 text-xs text-amber-300 w-24 focus:outline-none focus:border-amber-400"
                placeholder="Rohit"
              />
            </div>
          </div>
        </div>

        {/* Studio Body: Left Sidebar Modules + Right Workspace */}
        <div className="flex-1 flex overflow-hidden">
          
          {/* Left Navigation: The 10 Modules from user prompt */}
          <div className="w-64 sm:w-72 bg-neutral-950 border-r border-neutral-800 overflow-y-auto p-3 space-y-1 shrink-0">
            <div className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider px-3 py-2">
              Ready-To-Use AI Tools
            </div>

            {MARKETING_STUDIO_DATA.modules.map((mod, idx) => {
              const isActive = activeModule === mod.id;
              const icons = [
                Instagram, Video, Star, Share2, Megaphone, 
                MessageSquare, Tag, ImageIcon, Search, FileText
              ];
              const IconComp = icons[idx] || Sparkles;

              return (
                <button
                  key={mod.id}
                  onClick={() => setActiveModule(mod.id)}
                  className={`w-full text-left px-3 py-2.5 rounded-lg text-xs font-semibold flex items-center gap-3 transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-amber-400 text-neutral-950 font-bold shadow-sm'
                      : 'text-neutral-300 hover:bg-neutral-800/80 hover:text-white'
                  }`}
                >
                  <IconComp className={`w-4 h-4 shrink-0 ${isActive ? 'text-neutral-950' : 'text-amber-400'}`} />
                  <span className="truncate">{mod.title}</span>
                </button>
              );
            })}

            {/* Master Business Context preview */}
            <div className="pt-4 mt-4 border-t border-neutral-800/80 px-2 space-y-2">
              <div className="text-[11px] font-semibold text-neutral-400">Master Prompt Formula:</div>
              <p className="text-[10px] text-neutral-400 leading-relaxed line-clamp-4 bg-neutral-900 p-2.5 rounded border border-neutral-800 font-mono">
                {MARKETING_STUDIO_DATA.businessContext}
              </p>
            </div>
          </div>

          {/* Right Workspace Panel */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 bg-neutral-900/60">
            
            {/* Module Top Bar: Title, Description & Prompt Copy */}
            <div className="bg-neutral-950 p-5 rounded-2xl border border-neutral-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h3 className="font-display text-xl sm:text-2xl font-bold uppercase text-white tracking-wide">
                  {currentModule.title}
                </h3>
                <p className="text-xs sm:text-sm text-neutral-400 mt-1">
                  {currentModule.description}
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => handleCopy(currentModule.promptText, `prompt-${currentModule.id}`)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-200 border border-neutral-700 transition-colors cursor-pointer"
                >
                  {copiedId === `prompt-${currentModule.id}` ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5 text-amber-400" />
                  )}
                  <span>{copiedId === `prompt-${currentModule.id}` ? 'Prompt Copied!' : 'Copy Exact AI Prompt'}</span>
                </button>
              </div>
            </div>

            {/* --- MODULE 1: 30-Day Instagram Calendar --- */}
            {activeModule === 'instagram-calendar' && (
              <div className="space-y-4">
                {/* Filter pills */}
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <div className="flex items-center gap-1.5 text-xs">
                    {(['All', 'Reel', 'Carousel', 'Story'] as const).map(type => (
                      <button
                        key={type}
                        onClick={() => setInstaFilter(type)}
                        className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer ${
                          instaFilter === type
                            ? 'bg-amber-400 text-neutral-950'
                            : 'bg-neutral-950 text-neutral-400 hover:text-white border border-neutral-800'
                        }`}
                      >
                        {type} {type !== 'All' ? `(${INSTAGRAM_30_DAYS.filter(p => p.type === type).length})` : `(30)`}
                      </button>
                    ))}
                  </div>

                  <span className="text-xs text-neutral-400">
                    Showing {filteredInsta.length} of 30 days
                  </span>
                </div>

                {/* Day Posts List */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filteredInsta.map((post) => (
                    <div
                      key={post.day}
                      className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 flex flex-col justify-between space-y-3"
                    >
                      <div>
                        <div className="flex items-center justify-between text-xs mb-2">
                          <span className="font-mono font-bold text-amber-400">Day {post.day}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-neutral-400">{post.category}</span>
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              post.type === 'Reel' ? 'bg-purple-950 text-purple-300 border border-purple-800' :
                              post.type === 'Carousel' ? 'bg-blue-950 text-blue-300 border border-blue-800' :
                              'bg-amber-950 text-amber-300 border border-amber-800'
                            }`}>
                              {post.type}
                            </span>
                          </div>
                        </div>

                        {/* Hook */}
                        <div className="text-xs font-semibold text-white bg-neutral-900 p-2 rounded mb-2">
                          🎯 <strong className="text-amber-300">Hook (0-3s):</strong> {post.hook}
                        </div>

                        {/* Caption */}
                        <p className="text-xs text-neutral-300 leading-relaxed">
                          {post.caption}
                        </p>

                        {/* CTA */}
                        <div className="text-[11px] text-amber-400/90 font-medium mt-2">
                          📣 <strong>CTA:</strong> {post.cta}
                        </div>

                        {/* Hashtags */}
                        <div className="flex flex-wrap gap-1 mt-2 text-[10px] text-neutral-400 font-mono">
                          {post.hashtags.map((h, hIdx) => (
                            <span key={hIdx} className="bg-neutral-900 px-1.5 py-0.5 rounded">
                              {h}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="pt-2 border-t border-neutral-800/80 flex items-center justify-end">
                        <button
                          onClick={() => handleCopy(`${post.caption}\n\n${post.cta}\n\n${post.hashtags.join(' ')}`, `insta-${post.day}`)}
                          className="inline-flex items-center gap-1 text-xs text-neutral-400 hover:text-white cursor-pointer"
                        >
                          {copiedId === `insta-${post.day}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedId === `insta-${post.day}` ? 'Copied' : 'Copy Caption & Tags'}</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* --- MODULE 2: Reel Scripts --- */}
            {activeModule === 'reel-scripts' && (
              <div className="space-y-6">
                {/* Reel selector buttons */}
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {REEL_SCRIPTS.map((r, rIdx) => (
                    <button
                      key={r.id}
                      onClick={() => setSelectedReelId(r.id)}
                      className={`p-2.5 rounded-xl text-left border transition-all cursor-pointer ${
                        selectedReelId === r.id
                          ? 'bg-amber-400 text-neutral-950 font-bold border-amber-400'
                          : 'bg-neutral-950 text-neutral-300 border-neutral-800 hover:bg-neutral-900'
                      }`}
                    >
                      <div className="text-[10px] uppercase tracking-wide opacity-80">Reel #{rIdx + 1}</div>
                      <div className="text-xs font-bold truncate mt-0.5">{r.topic}</div>
                    </button>
                  ))}
                </div>

                {/* Selected Reel Teleprompter & Shot Breakdown */}
                <div className="bg-neutral-950 border border-neutral-800 rounded-2xl p-6 space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-800 pb-4">
                    <div>
                      <span className="text-xs text-amber-400 font-mono font-bold">Duration: {selectedReel.duration}</span>
                      <h4 className="font-display text-2xl font-bold uppercase text-white tracking-wide mt-0.5">
                        {selectedReel.topic}
                      </h4>
                    </div>

                    <button
                      onClick={() => handleCopy(
                        `Topic: ${selectedReel.topic}\nDuration: ${selectedReel.duration}\nAudio: ${selectedReel.audioSuggestion}\n\nVoiceover:\n${selectedReel.voiceover}\n\nOn-Screen Text:\n${selectedReel.onScreenText.join('\n')}\n\nShot List:\n${selectedReel.shotList.map(s => `${s.shot}: ${s.visual}`).join('\n')}`,
                        `reel-${selectedReel.id}`
                      )}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white cursor-pointer self-start sm:self-auto"
                    >
                      {copiedId === `reel-${selectedReel.id}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-amber-400" />}
                      <span>Copy Full Script</span>
                    </button>
                  </div>

                  {/* Audio Suggestion */}
                  <div className="bg-neutral-900 p-3.5 rounded-xl border border-neutral-800 text-xs flex items-center gap-2">
                    <span className="text-amber-400 font-bold">🎵 Trending Audio Suggestion:</span>
                    <span className="text-neutral-200">{selectedReel.audioSuggestion}</span>
                  </div>

                  {/* Voiceover Prompter Box */}
                  <div className="space-y-2">
                    <div className="text-xs font-bold uppercase text-amber-400 tracking-wider">
                      Teleprompter / Voiceover (English + Light Hinglish):
                    </div>
                    <div className="p-4 rounded-xl bg-neutral-900/90 border border-neutral-800 text-sm sm:text-base text-neutral-100 font-sans leading-relaxed">
                      &ldquo;{selectedReel.voiceover}&rdquo;
                    </div>
                  </div>

                  {/* Shot List & On-Screen Text Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                    {/* Shot List */}
                    <div className="space-y-2.5">
                      <div className="text-xs font-bold uppercase text-neutral-400 tracking-wider">
                        Camera Angle & Shot List:
                      </div>
                      <div className="space-y-2">
                        {selectedReel.shotList.map((shot, sIdx) => (
                          <div key={sIdx} className="p-3 rounded-lg bg-neutral-900/50 border border-neutral-800/80 text-xs">
                            <span className="font-mono text-amber-400 font-bold block mb-0.5">{shot.shot}</span>
                            <span className="text-neutral-300">{shot.visual}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* On-Screen Text */}
                    <div className="space-y-2.5">
                      <div className="text-xs font-bold uppercase text-neutral-400 tracking-wider">
                        On-Screen Captions & Graphics:
                      </div>
                      <div className="space-y-2">
                        {selectedReel.onScreenText.map((txt, tIdx) => (
                          <div key={tIdx} className="p-3 rounded-lg bg-neutral-900/50 border border-neutral-800/80 text-xs flex items-center gap-2">
                            <span className="w-5 h-5 rounded-full bg-amber-400 text-neutral-950 flex items-center justify-center font-bold text-[10px] shrink-0">
                              {tIdx + 1}
                            </span>
                            <span className="text-white font-medium">{txt}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            )}

            {/* --- MODULE 3: Google Review Replies --- */}
            {activeModule === 'google-review-replies' && (
              <div className="space-y-6">
                <div className="text-xs text-neutral-400">
                  Includes 10 warm, personalized replies for 5-star praises (clean space, helpful trainers, fair pricing) + 3 professional de-escalation responses under 50 words.
                </div>

                <div className="space-y-3">
                  {REVIEW_REPLIES.map((reply) => (
                    <div
                      key={reply.id}
                      className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 sm:p-5 flex flex-col md:flex-row md:items-start justify-between gap-4"
                    >
                      <div className="md:w-60 shrink-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            reply.type === 'positive' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'
                          }`}>
                            {reply.type === 'positive' ? 'Positive Review' : 'Critical Feedback'}
                          </span>
                        </div>
                        <span className="text-xs text-amber-400 font-semibold">{reply.mentionKeyword}</span>
                        <p className="text-xs text-neutral-400 italic mt-1 line-clamp-2">
                          &ldquo;{reply.reviewSnippet}&rdquo;
                        </p>
                      </div>

                      <div className="flex-1 space-y-2">
                        <div className="text-xs font-semibold text-neutral-400">Official Gym Response:</div>
                        <p className="text-xs sm:text-sm text-neutral-200 leading-relaxed bg-neutral-900 p-3 rounded-lg border border-neutral-800/80">
                          {reply.replyText}
                        </p>
                        <div className="text-[11px] text-neutral-500 font-mono">
                          Length: {reply.replyText.split(/\s+/).length} words (&lt; 50 words requirement satisfied)
                        </div>
                      </div>

                      <div className="shrink-0 flex items-center md:items-start">
                        <button
                          onClick={() => handleCopy(reply.replyText, `reply-${reply.id}`)}
                          className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-300 transition-colors flex items-center gap-1.5 cursor-pointer"
                        >
                          {copiedId === `reply-${reply.id}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedId === `reply-${reply.id}` ? 'Copied' : 'Copy'}</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* --- MODULE 4: Google Business Profile Posts --- */}
            {activeModule === 'google-business-posts' && (
              <div className="space-y-4">
                <div className="text-xs text-neutral-400">
                  8 ready-to-publish Google Business Profile updates (&lt; 150 words) with clear CTA buttons.
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {GBP_POSTS.map((gbp) => {
                    const wordCount = gbp.content.split(/\s+/).length;
                    return (
                      <div
                        key={gbp.id}
                        className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 flex flex-col justify-between space-y-4"
                      >
                        <div>
                          <div className="flex items-center justify-between text-xs mb-2">
                            <span className="font-mono text-amber-400 font-bold">Post #{gbp.id}</span>
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-neutral-900 border border-neutral-800 text-neutral-300">
                              CTA: {gbp.ctaButton}
                            </span>
                          </div>

                          <h4 className="font-bold text-white text-sm mb-2">
                            {gbp.title}
                          </h4>

                          <p className="text-xs text-neutral-300 leading-relaxed bg-neutral-900/50 p-3 rounded-lg border border-neutral-800/80">
                            {gbp.content}
                          </p>

                          <div className="text-[11px] text-neutral-500 font-mono mt-2">
                            {wordCount} words (within 150 words limit)
                          </div>
                        </div>

                        <div className="pt-2 border-t border-neutral-800/80 flex items-center justify-between">
                          <span className="text-[11px] text-neutral-400">Recommended button: <strong>{gbp.ctaButton}</strong></span>
                          <button
                            onClick={() => handleCopy(`${gbp.title}\n\n${gbp.content}\n\nCTA Button: ${gbp.ctaButton}`, `gbp-${gbp.id}`)}
                            className="inline-flex items-center gap-1 text-xs text-neutral-300 hover:text-white cursor-pointer"
                          >
                            {copiedId === `gbp-${gbp.id}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-amber-400" />}
                            <span>{copiedId === `gbp-${gbp.id}` ? 'Copied' : 'Copy Post'}</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* --- MODULE 5: Meta & Google Ad Copy --- */}
            {activeModule === 'ad-copy' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <div className="text-xs text-neutral-400">
                    Ads automatically inject your custom offer: <strong className="text-amber-400">&ldquo;{customOffer}&rdquo;</strong>.
                  </div>

                  <div className="flex items-center gap-1.5 text-xs">
                    {(['All', 'Meta', 'Google'] as const).map(p => (
                      <button
                        key={p}
                        onClick={() => setAdPlatform(p)}
                        className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer ${
                          adPlatform === p
                            ? 'bg-amber-400 text-neutral-950'
                            : 'bg-neutral-950 text-neutral-400 hover:text-white border border-neutral-800'
                        }`}
                      >
                        {p} Ads
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  {AD_COPY_DATA
                    .filter(ad => adPlatform === 'All' || ad.platform === adPlatform)
                    .map((ad, aIdx) => {
                      const descriptionWithOffer = ad.description.replace('[offer]', customOffer);
                      return (
                        <div
                          key={aIdx}
                          className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 flex flex-col md:flex-row md:items-start justify-between gap-4"
                        >
                          <div className="md:w-48 shrink-0">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              ad.platform === 'Meta' ? 'bg-indigo-950 text-indigo-300 border border-indigo-800' : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            }`}>
                              {ad.platform} Search / Feed
                            </span>
                            <div className="text-xs text-neutral-400 mt-2">
                              Targeting:
                            </div>
                            <div className="text-[11px] text-neutral-300 mt-0.5">
                              {ad.targetAudience}
                            </div>
                          </div>

                          <div className="flex-1 space-y-2">
                            <div>
                              <div className="flex items-center justify-between text-xs text-neutral-400 mb-1">
                                <span>Headline:</span>
                                <span className="font-mono text-[11px] text-neutral-500">
                                  {ad.headline.length} / 30 chars
                                </span>
                              </div>
                              <div className="text-sm font-bold text-white bg-neutral-900 p-2.5 rounded border border-neutral-800">
                                {ad.headline}
                              </div>
                            </div>

                            <div>
                              <div className="flex items-center justify-between text-xs text-neutral-400 mb-1">
                                <span>Description:</span>
                                <span className="font-mono text-[11px] text-neutral-500">
                                  {descriptionWithOffer.length} / 90 chars
                                </span>
                              </div>
                              <div className="text-xs text-neutral-300 bg-neutral-900 p-2.5 rounded border border-neutral-800">
                                {descriptionWithOffer}
                              </div>
                            </div>
                          </div>

                          <div className="shrink-0 flex items-start">
                            <button
                              onClick={() => handleCopy(`Headline: ${ad.headline}\nDescription: ${descriptionWithOffer}`, `ad-${aIdx}`)}
                              className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-300 transition-colors flex items-center gap-1.5 cursor-pointer"
                            >
                              {copiedId === `ad-${aIdx}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                              <span>{copiedId === `ad-${aIdx}` ? 'Copied' : 'Copy Ad'}</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            )}

            {/* --- MODULE 6: WhatsApp Follow-Up Cadence --- */}
            {activeModule === 'whatsapp-followup' && (
              <div className="space-y-6">
                <div className="text-xs text-neutral-400">
                  Automated 4-message sequence for unenrolled enquiries. Every message is kept strictly under 40 words.
                </div>

                <div className="space-y-4">
                  {WHATSAPP_CADENCE.map((wa, wIdx) => {
                    const messageRendered = wa.text
                      .replace(/\[Name\]/g, customName)
                      .replace(/\[offer\]/g, customOffer);
                    const wordCount = messageRendered.split(/\s+/).length;
                    const testUrl = `https://wa.me/?text=${encodeURIComponent(messageRendered)}`;

                    return (
                      <div
                        key={wIdx}
                        className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 flex flex-col md:flex-row md:items-start justify-between gap-4"
                      >
                        <div className="md:w-56 shrink-0">
                          <span className="font-mono text-xs font-bold text-amber-400 bg-amber-400/10 px-2.5 py-1 rounded">
                            {wa.step}
                          </span>
                          <div className="text-xs text-white font-semibold mt-2">
                            {wa.timing}
                          </div>
                          <div className="text-xs text-neutral-400 mt-1">
                            🎯 Objective: {wa.goal}
                          </div>
                        </div>

                        <div className="flex-1 space-y-2">
                          <div className="text-xs font-semibold text-neutral-400">WhatsApp Preview:</div>
                          <div className="p-3.5 bg-emerald-950/20 border border-emerald-900/50 rounded-xl text-xs sm:text-sm text-neutral-200 leading-relaxed font-sans">
                            {messageRendered}
                          </div>
                          <div className="text-[11px] text-neutral-500 font-mono">
                            {wordCount} words (Satisfies under 40 words constraint)
                          </div>
                        </div>

                        <div className="shrink-0 flex items-center md:flex-col gap-2">
                          <button
                            onClick={() => handleCopy(messageRendered, `wa-${wIdx}`)}
                            className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-300 transition-colors flex items-center gap-1.5 cursor-pointer"
                          >
                            {copiedId === `wa-${wIdx}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                            <span>{copiedId === `wa-${wIdx}` ? 'Copied' : 'Copy'}</span>
                          </button>

                          <a
                            href={testUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-xs font-semibold text-white transition-colors flex items-center gap-1.5"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>Test</span>
                          </a>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* --- MODULE 7: 10 Membership Campaigns --- */}
            {activeModule === 'membership-offers' && (
              <div className="space-y-4">
                <div className="text-xs text-neutral-400">
                  10 creative campaigns tailored to working professionals, college students, and homemakers in Gurugram.
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {MEMBERSHIP_OFFERS.map((offer) => (
                    <div
                      key={offer.id}
                      className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 flex flex-col justify-between space-y-4"
                    >
                      <div>
                        <div className="flex items-center justify-between text-xs mb-2">
                          <span className="font-mono text-amber-400 font-bold">Campaign #{offer.id}</span>
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-400/10 text-amber-300 border border-amber-400/20">
                            {offer.badge}
                          </span>
                        </div>

                        <h4 className="font-bold text-white text-base mb-2">
                          {offer.title}
                        </h4>

                        <div className="space-y-2 text-xs">
                          <div>
                            <span className="text-neutral-400 font-semibold">Offer Mechanics: </span>
                            <span className="text-neutral-200">{offer.mechanics}</span>
                          </div>
                          <div>
                            <span className="text-neutral-400 font-semibold">Target Audience: </span>
                            <span className="text-neutral-300">{offer.targetAudience}</span>
                          </div>
                          <div>
                            <span className="text-neutral-400 font-semibold">Promotion Playbook: </span>
                            <span className="text-amber-400/90">{offer.promotionPlaybook}</span>
                          </div>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-neutral-800/80 flex items-center justify-end">
                        <button
                          onClick={() => handleCopy(
                            `Campaign: ${offer.title}\nMechanics: ${offer.mechanics}\nTarget: ${offer.targetAudience}\nPromotion: ${offer.promotionPlaybook}`,
                            `offer-${offer.id}`
                          )}
                          className="inline-flex items-center gap-1 text-xs text-neutral-400 hover:text-white cursor-pointer"
                        >
                          {copiedId === `offer-${offer.id}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-amber-400" />}
                          <span>{copiedId === `offer-${offer.id}` ? 'Copied' : 'Copy Campaign'}</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* --- MODULE 8: AI Image & Poster Prompts --- */}
            {activeModule === 'image-prompts' && (
              <div className="space-y-6">
                <div className="text-xs text-neutral-400">
                  Ready-to-use prompts for Midjourney, DALL-E, or Gemini image generation, paired with real generated high-res results for My Fitness Pro Gym.
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Image 1 Prompt & Result */}
                  <div className="bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden p-5 space-y-4">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-amber-400">Prompt 1: Wide Shot Gym Interior (16:9)</span>
                      <button
                        onClick={() => handleCopy(
                          "Photorealistic wide shot of a bright, spacious, clean modern gym in India, with a trainer guiding a client on free weights, warm motivating lighting, energetic mood, no text, 16:9.",
                          "img-prompt-1"
                        )}
                        className="text-xs text-neutral-400 hover:text-white flex items-center gap-1 cursor-pointer"
                      >
                        {copiedId === 'img-prompt-1' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>Copy</span>
                      </button>
                    </div>

                    <div className="p-3 bg-neutral-900 rounded-lg text-xs font-mono text-neutral-300 border border-neutral-800">
                      &ldquo;Photorealistic wide shot of a bright, spacious, clean modern gym in India, with a trainer guiding a client on free weights, warm motivating lighting, energetic mood, no text, 16:9.&rdquo;
                    </div>

                    <div className="rounded-lg overflow-hidden border border-neutral-800 aspect-16/9 bg-neutral-900">
                      <img
                        src="/src/assets/images/gym_hero_main_1793441842625.jpg"
                        alt="Gym Interior Generated Asset"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>

                  {/* Image 2 Prompt & Result */}
                  <div className="bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden p-5 space-y-4">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-amber-400">Prompt 2: CrossFit Functional Turf (4:3)</span>
                      <button
                        onClick={() => handleCopy(
                          "Dynamic shot of a functional training and CrossFit area inside a modern Indian fitness club, kettlebells, barbells, battle ropes, clean rubber mat flooring, energetic atmosphere, natural daylight through glass windows, 8k commercial fitness photography",
                          "img-prompt-2"
                        )}
                        className="text-xs text-neutral-400 hover:text-white flex items-center gap-1 cursor-pointer"
                      >
                        {copiedId === 'img-prompt-2' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>Copy</span>
                      </button>
                    </div>

                    <div className="p-3 bg-neutral-900 rounded-lg text-xs font-mono text-neutral-300 border border-neutral-800">
                      &ldquo;Dynamic shot of a functional training and CrossFit area inside a modern Indian fitness club, kettlebells, barbells, battle ropes, clean rubber mat flooring, energetic atmosphere, natural daylight...&rdquo;
                    </div>

                    <div className="rounded-lg overflow-hidden border border-neutral-800 aspect-16/9 bg-neutral-900">
                      <img
                        src="/src/assets/images/gym_crossfit_training_1793441843330.jpg"
                        alt="CrossFit Arena Generated Asset"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* --- MODULE 9: Website & SEO Kit --- */}
            {activeModule === 'website-seo' && (
              <div className="space-y-6">
                <div className="bg-neutral-950 border border-neutral-800 rounded-2xl p-6 space-y-5">
                  <div className="border-b border-neutral-800 pb-4">
                    <h4 className="font-display text-xl font-bold uppercase text-white">
                      Search Engine Metadata & Keywords
                    </h4>
                    <p className="text-xs text-neutral-400 mt-1">
                      Engineered for Google Search & Map Pack rankings in Sector 52 & Ardee City Gurugram.
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between text-xs text-neutral-400 mb-1">
                        <span>Meta Title (&lt; 60 chars):</span>
                        <span className="font-mono text-[11px] text-amber-400">55 / 60 chars</span>
                      </div>
                      <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-lg text-sm font-semibold text-white flex items-center justify-between">
                        <span>My Fitness Pro Gym | Sector 52 Ardee City Gurugram</span>
                        <button
                          onClick={() => handleCopy("My Fitness Pro Gym | Sector 52 Ardee City Gurugram", "meta-title")}
                          className="text-xs text-neutral-400 hover:text-white"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between text-xs text-neutral-400 mb-1">
                        <span>Meta Description (&lt; 155 chars):</span>
                        <span className="font-mono text-[11px] text-amber-400">142 / 155 chars</span>
                      </div>
                      <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-lg text-xs text-neutral-300 leading-relaxed flex items-center justify-between">
                        <span>Premier gym in Ardee City, Sector 52, Gurugram. 4.9★ Google rating. Personal training, CrossFit, aerobics, dance fitness, and custom diet plans.</span>
                        <button
                          onClick={() => handleCopy("Premier gym in Ardee City, Sector 52, Gurugram. 4.9★ Google rating. Personal training, CrossFit, aerobics, dance fitness, and custom diet plans.", "meta-desc")}
                          className="text-xs text-neutral-400 hover:text-white shrink-0 ml-2"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div>
                      <div className="text-xs text-neutral-400 mb-1.5 font-semibold">
                        Primary Target Keywords Naturally Integrated:
                      </div>
                      <div className="flex flex-wrap gap-2 text-xs">
                        <span className="bg-amber-400/10 text-amber-300 border border-amber-400/30 px-2.5 py-1 rounded">gym in Gurugram</span>
                        <span className="bg-amber-400/10 text-amber-300 border border-amber-400/30 px-2.5 py-1 rounded">personal trainer in Sector 52</span>
                        <span className="bg-amber-400/10 text-amber-300 border border-amber-400/30 px-2.5 py-1 rounded">CrossFit Gurugram</span>
                        <span className="bg-neutral-900 text-neutral-300 border border-neutral-800 px-2.5 py-1 rounded">gym near Ardee Mall</span>
                        <span className="bg-neutral-900 text-neutral-300 border border-neutral-800 px-2.5 py-1 rounded">dance fitness sector 52</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* --- MODULE 10: Diet & Workout Handouts --- */}
            {activeModule === 'diet-workout-handouts' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between gap-4">
                  <div className="text-xs text-neutral-400">
                    Handouts designed for front-desk printing and member onboarding.
                  </div>
                  <button
                    onClick={() => window.print()}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-white cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5 text-amber-400" />
                    <span>Print Handout Sheet</span>
                  </button>
                </div>

                <div className="bg-neutral-950 border border-neutral-800 rounded-2xl p-6 space-y-4">
                  <div className="border-b border-neutral-800 pb-3">
                    <span className="text-xs font-bold uppercase text-amber-400">Handout 1</span>
                    <h4 className="font-display text-xl font-bold uppercase text-white">
                      {INDIAN_VEG_DIET_CHART.title}
                    </h4>
                    <p className="text-xs text-neutral-400 mt-1">{INDIAN_VEG_DIET_CHART.macroSplit}</p>
                  </div>

                  <div className="space-y-2">
                    {INDIAN_VEG_DIET_CHART.meals.map((meal, mIdx) => (
                      <div key={mIdx} className="p-3 bg-neutral-900 rounded-lg border border-neutral-800/80 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="sm:w-44 font-semibold text-white flex items-center gap-2">
                          <span className="text-amber-400 font-mono">{meal.time}</span>
                          <span>{meal.phase}</span>
                        </div>
                        <div className="flex-1 text-neutral-300">{meal.items}</div>
                      </div>
                    ))}
                  </div>

                  <div className="pt-2 text-xs text-neutral-500 italic">
                    {INDIAN_VEG_DIET_CHART.disclaimer}
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>

      </div>
    </div>
  );
};
