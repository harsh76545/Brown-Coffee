import React, { useState } from 'react';
import { MapPin, Phone, Clock, MessageSquare, ExternalLink, CheckCircle } from 'lucide-react';
import { GYM_DETAILS } from '../data/gymData';

export const LocationContactSection: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    serviceInterest: 'CrossFit & Conditioning',
    preferredTime: 'Morning (6 AM - 9 AM)'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) return;
    setSubmitted(true);
  };

  const whatsappUrl = `https://wa.me/${GYM_DETAILS.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(
    `Hi My Fitness Pro Gym! I would like to enquire about membership and a free trial pass in Sector 52, Gurugram.`
  )}`;

  return (
    <section id="location" className="py-20 bg-neutral-950 border-b border-neutral-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Gym Address & Contacts */}
          <div className="lg:col-span-6 space-y-8">
            <div>
              <div className="text-xs uppercase tracking-widest text-amber-400 font-semibold mb-2">
                Visit Us in Ardee City
              </div>
              <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold uppercase text-white tracking-tight">
                Sector 52 Gurugram Facility
              </h2>
              <p className="text-sm sm:text-base text-neutral-400 mt-3 leading-relaxed">
                Conveniently located in Ardee City near Ardee Mall with dedicated parking. Whether you are coming from Wazirabad, Golf Course Road, or DLF Phase 4, reaching us is effortless.
              </p>
            </div>

            {/* Quick Contact Cards */}
            <div className="space-y-4 text-sm">
              <div className="bg-neutral-900/60 p-4 rounded-xl border border-neutral-800 flex items-start gap-4">
                <MapPin className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-white text-base">Gym Address</div>
                  <div className="text-neutral-300 mt-0.5">{GYM_DETAILS.location}</div>
                  <div className="text-xs text-neutral-500 mt-0.5">Landmark: {GYM_DETAILS.landmark}</div>
                </div>
              </div>

              <div className="bg-neutral-900/60 p-4 rounded-xl border border-neutral-800 flex items-start gap-4">
                <Clock className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-white text-base">Operating Hours</div>
                  <div className="text-neutral-300 mt-0.5">Monday – Saturday: <span className="text-white font-medium">{GYM_DETAILS.hours.weekdays}</span></div>
                  <div className="text-neutral-300">Sunday: <span className="text-white font-medium">{GYM_DETAILS.hours.sunday}</span></div>
                </div>
              </div>

              <div className="bg-neutral-900/60 p-4 rounded-xl border border-neutral-800 flex items-start gap-4">
                <Phone className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-white text-base">Direct Front Desk & WhatsApp</div>
                  <div className="text-neutral-300 mt-0.5">{GYM_DETAILS.phone} · Instant WhatsApp Support</div>
                  <div className="text-xs text-neutral-500 mt-0.5">Response time typically under 10 minutes</div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-sm"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Chat on WhatsApp</span>
              </a>

              <a
                href={`tel:${GYM_DETAILS.phone.replace(/\s+/g, '')}`}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-white font-bold text-xs uppercase tracking-wider transition-colors"
              >
                <Phone className="w-4 h-4" />
                <span>Call Reception</span>
              </a>

              <a
                href="https://maps.google.com/?q=My+Fitness+Pro+Gym+Ardee+City+Sector+52+Gurugram"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-3 text-xs font-semibold text-neutral-400 hover:text-white transition-colors"
              >
                <span>Get Directions</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Right Column: Direct Quick Pass Reservation Form */}
          <div className="lg:col-span-6">
            <div className="bg-neutral-900 p-7 sm:p-9 rounded-2xl border border-neutral-800 shadow-xl">
              <div className="text-xs text-amber-400 font-bold uppercase tracking-wider mb-1">
                Instant Reservation
              </div>
              <h3 className="font-display text-2xl sm:text-3xl font-bold uppercase text-white tracking-wide mb-2">
                Get In Touch with a Trainer
              </h3>
              <p className="text-xs sm:text-sm text-neutral-400 mb-6">
                Fill in your details below and Coach Vikram will confirm your session within 2 hours.
              </p>

              {submitted ? (
                <div className="p-6 bg-emerald-950/40 border border-emerald-800/80 rounded-xl text-center space-y-3">
                  <CheckCircle className="w-10 h-10 text-emerald-400 mx-auto" />
                  <h4 className="font-display text-xl font-bold text-white uppercase">
                    Pass Reserved Successfully!
                  </h4>
                  <p className="text-xs sm:text-sm text-neutral-300">
                    Thank you <strong className="text-white">{formData.name}</strong>! We have reserved your trial pass for {formData.preferredTime}. Our front desk is expecting you.
                  </p>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="text-xs font-bold text-amber-400 underline hover:text-amber-300 mt-2 block mx-auto cursor-pointer"
                  >
                    Send another enquiry
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase text-neutral-400 mb-1.5">
                      Your Full Name
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Rahul Verma"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase text-neutral-400 mb-1.5">
                      Phone Number (for WhatsApp Pass confirmation)
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="+91 98XXX XXXXX"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold uppercase text-neutral-400 mb-1.5">
                        Area of Interest
                      </label>
                      <select
                        value={formData.serviceInterest}
                        onChange={(e) => setFormData({ ...formData, serviceInterest: e.target.value })}
                        className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-amber-400"
                      >
                        <option>CrossFit & Conditioning</option>
                        <option>1-on-1 Personal Training</option>
                        <option>Dance Fitness & Zumba</option>
                        <option>Indoor Spin Cycling</option>
                        <option>Strength & Free Weights</option>
                        <option>Indian Diet Consultation</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold uppercase text-neutral-400 mb-1.5">
                        Preferred Workout Time
                      </label>
                      <select
                        value={formData.preferredTime}
                        onChange={(e) => setFormData({ ...formData, preferredTime: e.target.value })}
                        className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-amber-400"
                      >
                        <option>Morning (6 AM - 9 AM)</option>
                        <option>Mid-Day (11 AM - 3 PM)</option>
                        <option>Evening (6 PM - 9 PM)</option>
                        <option>Late Night (9 PM - 10:30 PM)</option>
                      </select>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 px-4 bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold text-xs sm:text-sm uppercase tracking-wider rounded-xl transition-all shadow-md shadow-amber-400/20 cursor-pointer mt-2"
                  >
                    Confirm My Free 1-Day Pass
                  </button>

                  <p className="text-[11px] text-neutral-500 text-center pt-1">
                    🔒 We respect your privacy. No spam calls. Only 1 confirmation message with your entry pass code.
                  </p>
                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
