import React, { useState } from 'react';
import { X, CheckCircle, MessageSquare, ArrowRight, Calendar, Dumbbell } from 'lucide-react';
import { GYM_DETAILS, PricingPlan, ClassScheduleItem } from '../data/gymData';

interface FreeTrialModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPlan?: PricingPlan | null;
  initialClass?: ClassScheduleItem | null;
}

export const FreeTrialModal: React.FC<FreeTrialModalProps> = ({
  isOpen,
  onClose,
  initialPlan,
  initialClass
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [timeSlot, setTimeSlot] = useState('Morning (6:30 AM – 8:30 AM)');
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;
    setIsSuccess(true);
  };

  const passInterest = initialClass 
    ? `Class: ${initialClass.title} (${initialClass.time})`
    : initialPlan 
    ? `Plan: ${initialPlan.name} (₹${initialPlan.price})`
    : '1-Day All-Access Free Trial Pass';

  const whatsappMessage = `Hi My Fitness Pro Gym! My name is ${name}. I want to claim my 1-Day Free Trial Pass for ${passInterest} during ${timeSlot} at Sector 52 Ardee City Gurugram. Please confirm my reservation!`;
  const whatsappUrl = `https://wa.me/${GYM_DETAILS.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(whatsappMessage)}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div 
        className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-lg p-6 sm:p-8 relative shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-neutral-400 hover:text-white rounded-lg transition-colors cursor-pointer"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {!isSuccess ? (
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-wider mb-1">
              <Dumbbell className="w-4 h-4" />
              <span>Sector 52 Gurugram · Ardee City</span>
            </div>

            <h3 className="font-display text-2xl sm:text-3xl font-bold uppercase text-white tracking-wide mb-2">
              Claim Your 1-Day Free Pass
            </h3>

            <p className="text-xs sm:text-sm text-neutral-300 mb-6">
              Test our clean and spacious workout floor, try any cardio or free weights, or join a group class with certified coaches. Zero payment required.
            </p>

            {/* Interest reminder if selected from cards */}
            {(initialPlan || initialClass) && (
              <div className="mb-5 p-3 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-amber-300 flex items-center gap-2">
                <Calendar className="w-4 h-4 shrink-0 text-amber-400" />
                <span>Selected: <strong>{passInterest}</strong></span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase text-neutral-400 mb-1.5">
                  Your Full Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Amit Kumar"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-neutral-400 mb-1.5">
                  WhatsApp Contact Number
                </label>
                <input
                  type="tel"
                  required
                  placeholder="+91 98XXX XXXXX"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-neutral-400 mb-1.5">
                  Preferred Time Slot
                </label>
                <select
                  value={timeSlot}
                  onChange={(e) => setTimeSlot(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-amber-400"
                >
                  <option>Morning (6:30 AM – 8:30 AM)</option>
                  <option>Mid-Day (11:00 AM – 1:00 PM)</option>
                  <option>Evening (6:00 PM – 8:00 PM)</option>
                  <option>Night (8:30 PM – 10:00 PM)</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 px-4 bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold text-xs sm:text-sm uppercase tracking-wider rounded-xl transition-all shadow-md shadow-amber-400/20 cursor-pointer mt-2"
              >
                Generate Free Pass & Reserve
              </button>

              <div className="text-[11px] text-neutral-500 text-center">
                Includes complimentary locker, sanitized shower access, and water bottle refill.
              </div>
            </form>
          </div>
        ) : (
          <div className="text-center py-4 space-y-4">
            <CheckCircle className="w-14 h-14 text-emerald-400 mx-auto" />
            
            <h3 className="font-display text-2xl font-bold uppercase text-white tracking-wide">
              Your Pass is Confirmed, {name}!
            </h3>

            <p className="text-sm text-neutral-300 leading-relaxed max-w-sm mx-auto">
              We have generated your guest access badge for <strong>{timeSlot}</strong>. Simply show your pass at the front desk when you arrive at Ardee City Sector 52.
            </p>

            <div className="p-4 bg-neutral-950 rounded-xl border border-neutral-800 text-xs text-neutral-400 text-left space-y-1">
              <div><strong>Location:</strong> Ardee City, Sector 52, Gurugram (Near Ardee Mall)</div>
              <div><strong>Pass Holder:</strong> {name} ({phone})</div>
              <div><strong>Access:</strong> Cardio, Free Weights, Functional Turf & Showers</div>
            </div>

            <div className="pt-2 flex flex-col gap-2.5">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Send Pass To Gym on WhatsApp</span>
              </a>

              <button
                onClick={onClose}
                className="w-full py-2.5 px-4 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
