import React from 'react';
import { GYM_DETAILS } from '../data/gymData';
import { MapPin, Phone, Instagram, Clock } from 'lucide-react';

interface FooterProps {
  onOpenMarketingStudio: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenMarketingStudio }) => {
  return (
    <footer className="bg-neutral-950 text-neutral-400 text-xs border-t border-neutral-900 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          
          {/* Brand Info */}
          <div className="md:col-span-1 space-y-3">
            <a href="#" className="font-display text-xl font-bold uppercase tracking-wider text-white">
              MY FITNESS PRO
            </a>
            <p className="text-neutral-400 text-xs leading-relaxed">
              Ardee City, Sector 52, Gurugram. 4.9★ rated fitness facility providing CrossFit, personal training, dance fitness, spin cycling, and custom Indian nutrition.
            </p>
            <div className="text-amber-400 font-semibold text-xs">
              Plans starting at ₹499 to ₹26,990
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-2">
            <div className="text-white font-semibold uppercase text-xs tracking-wider mb-2">
              Programs
            </div>
            <ul className="space-y-1.5">
              <li><a href="#services" className="hover:text-amber-400 transition-colors">CrossFit & Functional Rig</a></li>
              <li><a href="#services" className="hover:text-amber-400 transition-colors">1-on-1 Personal Training</a></li>
              <li><a href="#services" className="hover:text-amber-400 transition-colors">Bollywood Dance Fitness</a></li>
              <li><a href="#services" className="hover:text-amber-400 transition-colors">Indoor Spin Cycling</a></li>
              <li><a href="#services" className="hover:text-amber-400 transition-colors">Free Weights & Power Racks</a></li>
            </ul>
          </div>

          {/* Member Resources */}
          <div className="space-y-2">
            <div className="text-white font-semibold uppercase text-xs tracking-wider mb-2">
              Member Resources
            </div>
            <ul className="space-y-1.5">
              <li><a href="#schedule" className="hover:text-amber-400 transition-colors">Class Timetable</a></li>
              <li><a href="#pricing" className="hover:text-amber-400 transition-colors">Transparent Pricing</a></li>
              <li><a href="#handouts" className="hover:text-amber-400 transition-colors">Indian Veg Diet Chart</a></li>
              <li><a href="#handouts" className="hover:text-amber-400 transition-colors">4-Week Beginner Plan</a></li>
              <li>
                <button
                  onClick={onOpenMarketingStudio}
                  className="hover:text-amber-400 transition-colors text-left font-medium text-amber-400/90 cursor-pointer"
                >
                  AI Marketing & Prompt Studio
                </button>
              </li>
            </ul>
          </div>

          {/* Timings & Contact */}
          <div className="space-y-2">
            <div className="text-white font-semibold uppercase text-xs tracking-wider mb-2">
              Hours & Contact
            </div>
            <div className="flex items-start gap-2">
              <Clock className="w-3.5 h-3.5 text-neutral-500 shrink-0 mt-0.5" />
              <span>Mon-Sat: 5:30 AM – 10:30 PM<br />Sun: 7:00 AM – 8:00 PM</span>
            </div>
            <div className="flex items-center gap-2 pt-1">
              <Phone className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
              <span>{GYM_DETAILS.phone}</span>
            </div>
            <div className="flex items-center gap-2">
              <Instagram className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
              <span>@myfitnesspro55</span>
            </div>
            <div className="flex items-start gap-2 pt-1">
              <MapPin className="w-3.5 h-3.5 text-neutral-500 shrink-0 mt-0.5" />
              <span>Sector 52, Ardee City, Gurugram</span>
            </div>
          </div>

        </div>

        {/* Quiet Bottom Strip */}
        <div className="pt-8 border-t border-neutral-900 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-[11px] text-neutral-500">
          <div>
            &copy; {new Date().getFullYear()} My Fitness Pro Gym. All rights reserved. Registered fitness facility, Sector 52 Gurugram.
          </div>
          <div className="flex items-center gap-4">
            <span>Clean & Sanitized Daily</span>
            <span>·</span>
            <span>Zero Lock-in Admission Charges</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
